package tests;
import cute.Cute;

/**
 * Author: Koushik Sen <ksen@cs.uiuc.edu>
 */
public class AssertTest2 extends Thread{

    synchronized public void run() {
        try {
            System.out.println("Nothing");
            this.wait();
        } catch (InterruptedException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    public static void main(String[] args) {
		int l,m,n,o,p,q,r;
		l=Cute.input.Integer();
		m=Cute.input.Integer();
		n=Cute.input.Integer();
		o=Cute.input.Integer();
		p=Cute.input.Integer();
		q=Cute.input.Integer();
		r=Cute.input.Integer();
		if((l<=200)||(m>=150))
                {
                    System.out.println("This a new trial");
                }
                else
                    {
                        if((n!=90)||(l>=150))
                            {
                                System.out.println("This a new trial");
                            }

                    System.out.println("This a not new trial");
                     }


                if((o!=9)&&(p>=0)||(q==2000))
                {
                    System.out.println("This a new ...............trial");
                }
                if((r!=89)||(o>=1501)||(q==2000)&&(m>=299)&&(p<=100))
                {
                    System.out.println("This a new ...............trial");
                }
                if((n!=9)&&(l>=1500)||(m==2000))
                {
                    System.out.println("This a new ...............trial");
                }
                if((o!=900)&&(l>=1500)&&(p==2000))
                {
                    System.out.println("This a new ...............trial");
                }
                if((q!=900)&&(p>=1500)&&(m==2000))
                {
                    System.out.println("This a new ...............trial");
                }


        AssertTest2 at = new AssertTest2();
        at.start();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
