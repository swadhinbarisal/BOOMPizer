package A1;

import cute.Cute;

public class Problem2_RERS2015 {
	

	public static int a308 =Cute.input.Integer();
	public static boolean a346 =Cute.input.Boolean();
	public static int a285 = Cute.input.Integer();
	public static int a38 = Cute.input.Integer();
	public static int a333 = Cute.input.Integer();
	public static int a339 =Cute.input.Integer();
	public static int a366 = Cute.input.Integer();
	public static int a26 = Cute.input.Integer();
	public static int a343 = Cute.input.Integer();
	public static int a100 = Cute.input.Integer();
	public static int a287 =Cute.input.Integer();
	public static boolean a105 =Cute.input.Boolean();
	public static int a243 =Cute.input.Integer();
	public static boolean a218 =Cute.input.Boolean();
	public static int a107 =Cute.input.Integer();
	public static int a293 =Cute.input.Integer();
	public static boolean a123 =Cute.input.Boolean();
	public static int a84 =Cute.input.Integer();
	public static boolean a130 =Cute.input.Boolean();
	public static int a122 = Cute.input.Integer();
	public static int a396 = Cute.input.Integer();
	public static int a322 =Cute.input.Integer();
	public static boolean a310 =Cute.input.Boolean();
	public static boolean a256 =Cute.input.Boolean();
	public static boolean a179 =Cute.input.Boolean();
	public static int a390 =Cute.input.Integer();
	public static int a275 = Cute.input.Integer();
	public static int a392 = Cute.input.Integer();
	public static int a276 =Cute.input.Integer();
	public static boolean a384 =Cute.input.Boolean();
	public static int a270 = Cute.input.Integer();
	public static boolean a318 =Cute.input.Boolean();
	public static int a76 = Cute.input.Integer();
	public static int a375 =Cute.input.Integer();
	public static int a187 =Cute.input.Integer();
	public static int a205 = Cute.input.Integer();
	public static int a181 = Cute.input.Integer();
	public static int a42 =Cute.input.Integer();
	public static int a389 = Cute.input.Integer();
	public static boolean a292 =Cute.input.Boolean();
	public static int a66 =Cute.input.Integer();
	public static int a113 = Cute.input.Integer();
	public static int a183 =Cute.input.Integer();
	public static int a350 = Cute.input.Integer();
	public static int a162 =Cute.input.Integer();
	public static int a378 = Cute.input.Integer();
	public static int a91 = Cute.input.Integer();
	public static int a259 =Cute.input.Integer();
	public static int a114 =Cute.input.Integer();
	public static int a284 = Cute.input.Integer();
	public static int a125 = Cute.input.Integer();
	public static boolean a296 =Cute.input.Boolean();
	public static int a271 = Cute.input.Integer();
	public static int a269 = Cute.input.Integer();
	public static int a254 = Cute.input.Integer();
	public static int a250 = Cute.input.Integer();
	public static int a229 =Cute.input.Integer();
	public static boolean a64 =Cute.input.Boolean();
	public static int a141 =Cute.input.Integer();
	public static int a198 =Cute.input.Integer();
	public static int a201 =Cute.input.Integer();
	public static int a356 =Cute.input.Integer();
	public static int a367 = Cute.input.Integer();
	public static int a313 = Cute.input.Integer();
	public static int a169 = Cute.input.Integer();
	public static boolean a115 =Cute.input.Boolean();
	public static boolean a247 =Cute.input.Boolean();
	public static boolean a265 =Cute.input.Boolean();
	public static int a236 =Cute.input.Integer();
	public static int a172 =Cute.input.Integer();
	public static int a263 = Cute.input.Integer();
	public static boolean a391 =Cute.input.Boolean();
	public static boolean a277 =Cute.input.Boolean();
	public static int a163 = Cute.input.Integer();
	public static int a301 = Cute.input.Integer();
	public static int a177 = Cute.input.Integer();
	public static int a303 =Cute.input.Integer();
	public static int a383 = Cute.input.Integer();
	public static int a300 =Cute.input.Integer();
	public static int a380 = Cute.input.Integer();
	public static boolean a398 =Cute.input.Boolean();
	public static int a48 = Cute.input.Integer();
	public static int a133 =Cute.input.Integer();
	public static int a370 = Cute.input.Integer();
	public static int a216 = Cute.input.Integer();
	public static int a314 =Cute.input.Integer();
	public static int a311 =Cute.input.Integer();
	public static int a19 =Cute.input.Integer();
	public static boolean a290 =Cute.input.Boolean();
	public static int a363 = Cute.input.Integer();
	public static int a338 = Cute.input.Integer();
	public static int a368 = Cute.input.Integer();
	public static boolean a399 =Cute.input.Boolean();
	public static int a328 =Cute.input.Integer();
	public static boolean cf= Cute.input.Boolean();
	public static int a155 =Cute.input.Integer();
	public static int a135 = Cute.input.Integer();
	public static int a225 = Cute.input.Integer();
	public static int a304 =Cute.input.Integer();
	public static boolean a379 =Cute.input.Boolean();
	public static int a326 = Cute.input.Integer();
	public static boolean a206 =Cute.input.Boolean();
	public static boolean a323 =Cute.input.Boolean();
	public static int a242 = Cute.input.Integer();
	public static int a213 = Cute.input.Integer();
	public static boolean a345 =Cute.input.Boolean();
	public static boolean a227 =Cute.input.Boolean();
	public static int a231 = Cute.input.Integer();
	public static int a233 = Cute.input.Integer();
	public static int a77 = Cute.input.Integer();
	public static int a354 =Cute.input.Integer();
	public static int a193 =Cute.input.Integer();
	public static int a168 = Cute.input.Integer();
	public static int a121 = Cute.input.Integer();
	public static int a147 = Cute.input.Integer();
	public static boolean a175 =Cute.input.Boolean();
	public static int a297 = Cute.input.Integer();
	public static int a36 =Cute.input.Integer();
	public static boolean a266 =Cute.input.Boolean();
	public static int a393 =Cute.input.Integer();
	public static int a124 = Cute.input.Integer();
	public static boolean a244 =Cute.input.Boolean();
	public static int a128 = Cute.input.Integer();
	public static int a208 = Cute.input.Integer();
	public static int a152 = Cute.input.Integer();
	public static int a373 = Cute.input.Integer();
	public static boolean a192 =Cute.input.Boolean();
	public static boolean a307 =Cute.input.Boolean();
	public static int a2 =Cute.input.Integer();
	public static boolean a83 =Cute.input.Boolean();
	public static int a337 = Cute.input.Integer();
	public static int a200 = Cute.input.Integer();
	public static int a364 = Cute.input.Integer();
	public static int a245 = Cute.input.Integer();
	public static int a253 = Cute.input.Integer();
	public static boolean a267 =Cute.input.Boolean();
	public static int a186 = Cute.input.Integer();
	public static int a127 =Cute.input.Integer();
	public static boolean a33 =Cute.input.Boolean();
	public static int a174 = Cute.input.Integer();
	public static int a70 = Cute.input.Integer();
	public static int a335 =Cute.input.Integer();
	public static boolean a302 =Cute.input.Boolean();
	public static int a387 = Cute.input.Integer();
	public static int a110 =Cute.input.Integer();
	public static int a41 =Cute.input.Integer();
	public static boolean a39 =Cute.input.Boolean();
	public static int a381 = Cute.input.Integer();
	public static int a400 = Cute.input.Integer();
	public static int a17 = Cute.input.Integer();
	public static int a352 = Cute.input.Integer();
	public static boolean a117 =Cute.input.Boolean();
	public static boolean a248 =Cute.input.Boolean();
	public static int a260 = Cute.input.Integer();
	public static int a43 = Cute.input.Integer();
	public static boolean a278 =Cute.input.Boolean();
	public static boolean a1 =Cute.input.Boolean();
	public static int a385 = Cute.input.Integer();
	public static int a289 = Cute.input.Integer();
	public static boolean a46 =Cute.input.Boolean();
	public static boolean a7 =Cute.input.Boolean();
	public static int a221 =Cute.input.Integer();
	public static int a148 = Cute.input.Integer();
	public static int a3 =Cute.input.Integer();
	public static boolean a235 =Cute.input.Boolean();
	public static int a118 = Cute.input.Integer();
	public static int a191 = Cute.input.Integer();
	public static int a298 = Cute.input.Integer();
	public static int a294 = Cute.input.Integer();
	public static boolean a309 =Cute.input.Boolean();
	public static int a224 = Cute.input.Integer();
	public static boolean a220 =Cute.input.Boolean();
	public static int a361 = Cute.input.Integer();
	public static int a178 = Cute.input.Integer();
	public static int a50 =Cute.input.Integer();
	public static int a92 = Cute.input.Integer();
	public static boolean a222 =Cute.input.Boolean();
	public static int a371 = Cute.input.Integer();
	public static boolean a16 =Cute.input.Boolean();
	public static boolean a27 =Cute.input.Boolean();
	public static int a126 =Cute.input.Integer();
	public static int a272 =Cute.input.Integer();
	public static boolean a281 =Cute.input.Boolean();
	public static int a71 = Cute.input.Integer();
	public static int a80 = Cute.input.Integer();
	public static int a252 =Cute.input.Integer();
	public static boolean a24 =Cute.input.Boolean();
	public static int a274 = Cute.input.Integer();
	public static int a57 = Cute.input.Integer();
	public static int a47 = Cute.input.Integer();
	public static boolean a119 =Cute.input.Boolean();
	public static int a241 = Cute.input.Integer();
	public static boolean a20 =Cute.input.Boolean();
	public static int a199 = Cute.input.Integer();
	public static int a161 = Cute.input.Integer();
	public static int a315 = Cute.input.Integer();
	public static int a189 = Cute.input.Integer();
	public static int a132 = Cute.input.Integer();;
	public static int a291 = Cute.input.Integer();
	public static int a58 =Cute.input.Integer();
	public static boolean a232 =Cute.input.Boolean();
	public static int a394 =Cute.input.Integer();
	public static boolean a56 =Cute.input.Boolean();
	public static int a332 =Cute.input.Integer();
	public static int a324 = Cute.input.Integer();
	public static boolean a279 =Cute.input.Boolean();
	public static int a355 = Cute.input.Integer();
	public static int a228 = Cute.input.Integer();
	public static boolean a330 =Cute.input.Boolean();
	public static int a59 =Cute.input.Integer();
	public static int a395 = Cute.input.Integer();
	public static int a146 = Cute.input.Integer();
	public static int a258 =Cute.input.Integer();
	public static boolean a246 =Cute.input.Boolean();
	public static int a251 = Cute.input.Integer();
	public static int a219 =Cute.input.Integer();
	public static boolean a273 =Cute.input.Boolean();
	public static int a305 = Cute.input.Integer();
	public static int a336 =Cute.input.Integer();
	public static int a159 = Cute.input.Integer();
	public static int a325 = Cute.input.Integer();
	public static int a340 = Cute.input.Integer();
	public static int a102 = Cute.input.Integer();
	public static int a171 = Cute.input.Integer();
	public static int a238 =Cute.input.Integer();
	public static int a81 =Cute.input.Integer();
	public static int a327 = Cute.input.Integer();
	public static boolean a334 =Cute.input.Boolean();
	public static int a204 = Cute.input.Integer();
	public static int a351 =Cute.input.Integer();
	public static int a261 = Cute.input.Integer();
	public static int a210 = Cute.input.Integer();
	public static int a288 = Cute.input.Integer();
	public static int a286 = Cute.input.Integer();
	public static int a299 =Cute.input.Integer();
	public static int a320 = Cute.input.Integer();
	public static int a10 = Cute.input.Integer();
	public static boolean a374 =Cute.input.Boolean();
	public static int a131 = Cute.input.Integer();
	public static int a362 = Cute.input.Integer();
	public static int a68 = Cute.input.Integer();
	public static boolean a34 =Cute.input.Boolean();
	public static int a52 = Cute.input.Integer();
	public static int a358 = Cute.input.Integer();
	public static int a86 = Cute.input.Integer();
	public static int a142 = Cute.input.Integer();
	public static int a209 = Cute.input.Integer();
	public static boolean a103 =Cute.input.Boolean();
	public static int a329 = Cute.input.Integer();
	public static int a153 =Cute.input.Integer();
	public static int a312 =Cute.input.Integer();
	public static int a88 =Cute.input.Integer();
	public static int a67 =Cute.input.Integer();
	public static int a61 = Cute.input.Integer();
	public static int a35 = Cute.input.Integer();
	public static int a62 = Cute.input.Integer();
	public static int a79 = Cute.input.Integer();
	public static int a109 = Cute.input.Integer();
	public static int a98 = Cute.input.Integer();
	public static int a72 =Cute.input.Integer();
	public static int a180 =Cute.input.Integer();
	public static int a170 = Cute.input.Integer();
	public static int a4 =Cute.input.Integer();
	public static int a14 =Cute.input.Integer();
	public static int a144 =Cute.input.Integer();
	public static int a5 =Cute.input.Integer();
	public static int a40 =Cute.input.Integer();
	public static int a21 = Cute.input.Integer();
	public static int a63 =Cute.input.Integer();
	public static int a150 =Cute.input.Integer();
	public static int a44 =Cute.input.Integer();
	public static int a195 =Cute.input.Integer();
	public static int a74 =Cute.input.Integer();
	public static int a23 = Cute.input.Integer();
	public static int a99 =Cute.input.Integer();
	public static int a145 = Cute.input.Integer();
	public static int a196 =Cute.input.Integer();
	public static int a75 =Cute.input.Integer();
	public static int a136 =Cute.input.Integer();
	public static int a13 =Cute.input.Integer();
	public static int a151 =Cute.input.Integer();


	private void errorCheck() {
	    if((a102 ==00) && (a383 ==0) && (a326 ==00) && (a10 ==0)){
	    	cf= false;
	    	throw new IllegalStateException( "error_0" );
	    }
	    if((a52 ==03) && (a383 ==0) && (a326 ==00) && (a10 ==0)){
	    	cf= false;
	    	throw new IllegalStateException( "error_1" );
	    }
	    if((a3==0) && (a263 ==00) && (a48 ==0) && (a10 ==0)){
	    	cf= false;
	    	throw new IllegalStateException( "error_2" );
	    }
	    if((a77 ==01) && (a263 ==0) && (a48 ==0) && (a10 ==0)){
	    	cf= false;
	    	throw new IllegalStateException( "error_3" );
	    }
	    if((a43 ==03) && (273 < a169) && (a326 ==04) && (a10 ==0)){
	    	cf= false;
	    	throw new IllegalStateException( "error_4" );
	    }
	    if((a147 ==01) && (a105==false) && (129 < a124) && (15 >= a124) && (a10 ==0)){
	    	cf= false;
	    	throw new IllegalStateException( "error_5" );
	    }
	    if((a50==0) && (a46==false) && (a48 ==00) && (a10 ==0)){
	    	cf= false;
	    	throw new IllegalStateException( "error_6" );
	    }
	    if((a48 ==0) && (a126==0) && (a326 ==03) && (a10 ==0)){
	    	cf= false;
	    	throw new IllegalStateException( "error_7" );
	    }
	    if((a161 ==0) && (a193==0) && (a48 ==0) && (a10 ==0)){
	    	cf= false;
	    	throw new IllegalStateException( "error_8" );
	    }
	    if((a171 ==01) && (a326 ==07) && (334 < a174) && (a10 ==0)){
	    	cf= false;
	    	throw new IllegalStateException( "error_9" );
	    }
	    if((a370 ==0) && (a263 ==03) && (a48 ==0) && (a10 ==0)){
	    	cf= false;
	    	throw new IllegalStateException( "error_10" );
	    }
}

private  void calculateOutputm13(boolean input) {
    if((a256==false) && (input==false) && (cf==false) && (a10 == 1) && (a153==0) && (a162==0)) {
    	a99 += (a99 + 20) > a99 ? 2 : 0;
    	cf = false;
    	a381 = ((a378 / a286) - -3);
    	a231 = ((((((a231 * a208) % 14999) % 13) + 167) - -1) - 1);
    	a308 = 1;
    	a142 = (((34 - -21865) + 2387) + 4363);
    	a269 = a68;
    	a10 = ((a337 / a337) - -3);
    	a243 = 1;
    	a266 = false;
    	a251 = (a380 - 9);
    	a371 = ((((((((a371 * a298) % 14999) - -26596) % 61) - 129) * 5) % 61) - 95);
    	a394 = 1;
    	a256 = false;
    	a19 = 0;
    	a313 = ((a210 - a367) + 2);
    	a345 = false;
    	a396 = ((((((a225 * a228) % 14999) % 72) + 90) / 5) - -84);
    	a346 = false;
    	a210 = (a253 - -2);
    	a334 = false;
    	a302 = false;
    	a221 = 1;
    	a209 = (((((((a209 * a396) % 14999) / 5) / 5) / 5) % 80) + 212);
    	a235 = false;
    	a337 = ((a378 / a340) + 1); 
    	System.out.println("Q");
    } 
    if((a209 <=  132) && (a10 == 1) && (a337 == 1) && (a153==0) && (a399==false) && (a236==0) && (a243==0) &&(cf==false)  && (a334==false)) {
    	a72 -= (a72 - 20) < a72 ? 1 : 0;
    	cf = false;
    	a284 = (((32 / 5) + 238) + 78);
    	a265 = false;
    	a270 = (a291 + 1);
    	a314 = 1;
    	a378 = ((a210 + a210) - 10);
    	a373 = (((64 + -25143) + 17680) * 4);
    	a227 = false;
    	a309 = false;
    	a400 = ((a291 + a291) + -2);
    	a228 = ((((((a396 * a371) % 14999) % 100) - -218) + -1) - -2);
    	a219 = 1;
    	a288 = (((((((a371 * a371) % 14999) - 22953) - 1237) / 5) % 77) - -226);
    	a380 = ((a210 * a291) - 24);
    	a392 = ((a291 * a210) + -31);
    	a279 = false;
    	a271 = (a251 - -9);
    	a224 = ((((((a368 * a371) % 14999) - -13063) % 105) + 287) - 0);
    	a327 = ((((11 + 23560) + 3537) * 1) - 26873);
    	a329 = ((a381 * a210) + -13);
    	a323 = false;
    	a358 = ((((78 - -12182) + -12374) + 24896) - 24808);
    	a229 = 1;
    	a312 = 1;
    	a241 = (((((((a368 * a371) % 14999) % 96) + 10) + 3224) / 5) + -583);
    	a276 = 1;
    	a225 = (((((48 * 10) / 3) * 10) / 9) + 36);
    	a320 = (a10 - -6);
    	a287 = 1;
    	a300 = 1;
    	a333 = ((a10 - a210) + 8);
    	a206 = false;
    	a278 = false;
    	a398 = false;
    	a384 = true;
    	a218 = false;
    	a393 = 1;
    	a233 = ((((83 - -47) + 22548) / 5) - 4408);
    	a324 = (((((((a396 * a371) % 14999) % 67) + 230) * 1) / 5) - -225);
    	a322 = 1;
    	a356 = 1;
    	a335 = 1;
    	a343 = (a291 - 1);
    	a290 = true;
    	a298 = ((((((a209 * a387) % 14999) / 5) / 5) % 64) + 77);
    	a303 = 1;
    	a362 = ((a210 * a291) + -27);
    	a391 = true;
    	a367 = ((a210 - a210) + 4);
    	a286 = ((a291 + a291) - 6);
    	a307 = false;
    	a352 = (a291 - -4);
    	a248 = true;
    	a299 = (a291 - -1);
    	a253 = (a313 + 2);
    	a213 = (((((a371 * a396) % 14999) + 11461) + -26457) - 2);
    	a390 = 1;
    	a339 = 1;
    	a208 = (((((((a368 * a209) % 14999) % 94) - -246) * 5) % 94) - -177);
    	a289 = (a10 + 6);
    	a340 = (a10 - -2);
    	a330 = false;
    	a285 = (((((((a396 * a371) % 14999) % 20) + 133) + 23190) / 5) + -4525);
    	a328 = 1;
    	a336 = 1;
    	a395 = ((a210 + a210) - 6);
    	a301 = (((((((a396 * a396) % 14999) % 33) - -112) * 5) % 33) + 82);
    	a355 = ((a10 / a337) - -3);
    	a247 = false;
    	a205 = (a68 + -5);
    	a293 = 1;
    	a201 = 1;
    	a361 = (((((((a396 * a371) % 14999) * 2) + -2) * 1) % 65) - -188);
    	a385 = ((((((a371 * a231) % 14999) - 12391) - 385) % 13) - -114);
    	a246 = false;
    	a350 = ((((((a209 * a396) % 14999) * 2) - -2) % 97) - -139);
    	a274 = (((((((97 * -7) / 10) * 10) / 9) + 15496) * -1) / 10);
    	a375 = 1;
    	a351 = 1;
    	a273 = true;
    	a275 = ((((((a371 * a396) % 14999) * 2) - 0) % 44) + -118); 
    	System.out.println("T");
    } 
}
private  void calculateOutputm14(boolean input) {
    if((a122 == 9) && (a308==0) && (a330==false) && (a10 == 1) && (a270 == 6) && (a381 == 3) && (cf==false) && (input==false) && (a290==false)) {
    	a72 -= (a72 - 20) < a72 ? 1 : 0;
    	cf = false;
    	a235 = true;
    	a339 = 0;
    	a298 = ((((((a285 * a231) % 14999) - 14995) / 5) + 23469) - 34976);
    	a253 = ((a340 - a340) + 7);
    	a276 = 0;
    	a391 = true;
    	a241 = ((((((a285 * a371) % 14999) % 63) - -171) - 2432) - -2430);
    	a309 = true;
    	a378 = (a253 - 2);
    	a183 = 1;
    	a201 = 0;
    	a351 = 0;
    	a284 = ((((((a371 * a241) % 14999) % 20) - -374) - 1) - -2);
    	a358 = ((((((a371 * a371) % 14999) - 5001) % 36) - -49) + 1);
    	a328 = 1;
    	a233 = ((((((((a284 * a285) % 14999) - -11229) % 54) + 201) * 5) % 54) + 157);
    	a238 = 0;
    	a381 = (a352 - 3);
    	a127 = 0;
    	a256 = false;
    	a346 = true;
    	a330 = false;
    	a303 = 0;
    	a324 = ((((((a371 * a231) % 14999) + 13096) % 84) + 383) + -1);
    	a367 = (a68 + -5);
    	a225 = ((((((a358 * a275) % 14999) + -11482) - -30214) * 1) * -1);
    	a278 = true;
    	a322 = 0;
    	a221 = 0;
    	a313 = (a378 + 1);
    	a10 = (a68 - 7);
    	a270 = (a251 - -6);
    	a273 = false;
    	a345 = false;
    	a219 = 0;
    	a243 = 0;
    	a229 = 0;
    	a300 = 1;
    	a175 = false;
    	a227 = true;
    	a323 = true;
    	a312 = 0;
    	a392 = (a210 + -6);
    	a302 = false;
    	a368 = ((((((((a368 * a387) % 14999) % 44) + 105) * 5) + -13962) % 44) - -132);
    	a286 = (a355 - 3);
    	a290 = false;
    	a252 = 0;
    	a385 = ((((((a385 * a324) % 14999) % 75) + 204) - -1) - 1);
    	a335 = 0;
    	a320 = (a333 - -7);
    	a356 = 0;
    	a333 = (a68 - 7); 
    	System.out.println("U");
    } 
    if((a368 <=  32) && (a351==0) && (a68 == 10) && (a273==false) && (a352 == 8) && (cf==false) && (input==false) && (a320 == 6)) {
    	cf = false;
    	a210 = ((a10 * a340) + 7);
    	a381 = a367;
    	a273 = false;
    	a235 = false;
    	a345 = false;
    	a183 = 1;
    	a270 = ((a352 * a367) - 25);
    	a238 = 1;
    	a351 = 1;
    	a307 = true;
    	a368 = (((((((a225 * a233) % 14999) % 13) - -44) - -3) + -18788) + 18783);
    	a355 = ((a10 * a333) - -5);
    	a333 = (a367 + -2);
    	a153 = 0;
    	a285 = (((((((a285 * a233) % 14999) / 5) + 13035) / 5) % 20) + 130);
    	a10 = (a122 + -3);
    	a340 = ((a313 * a251) + -1);
    	a243 = 1;
    	a236 = 0;
    	a385 = ((((((((a385 * a368) % 14999) % 75) + 203) * 5) - -15678) % 75) - -183);
    	a251 = (a400 - 6);
    	a102 = ((a10 * a10) + -22);
    	a221 = 1;
    	a308 = 1;
    	a231 = (((((((a231 * a387) % 14999) / 5) * 5) * 2) % 13) + 166);
    	a330 = false;
    	a247 = false;
    	a302 = false;
    	a313 = (a320 + -1);
    	a336 = 0;
    	a290 = false;
    	a252 = 0;
    	a387 = ((((((a387 * a298) % 14999) % 25) - -92) - 1) + 0); 
    	System.out.println("U");
    } 
}
private  void calculateOutputm15(boolean input) {
    if((input==false) && (a271 == 9) && (a10 == 1) && (a275 <=  164) && (a208 <=  152) &&  (cf==false) && (a68 == 10)) {
    	a150 -= (a150 - 20) < a150 ? 1 : 0;
    	cf = false;
    	a362 = (a381 + 6);
    	a238 = 1;
    	a368 = (((((((a368 * a371) % 14999) / 5) % 13) + 47) + 24323) + -24322);
    	a302 = false;
    	a251 = ((a271 - a10) - 6);
    	a253 = (a313 + 2);
    	a275 = (((((((a275 * a387) % 14999) / 5) * 5) - -12999) % 44) + -118);
    	a371 = ((((((((a231 * a233) % 14999) % 61) - 121) - 2) * 5) % 61) + -61);
    	a299 = ((a392 / a392) - -5);
    	a313 = (a367 - -1);
    	a383 = ((a68 - a10) + -5);
    	a243 = 1;
    	a256 = false;
    	a381 = (a122 - 11);
    	a231 = ((((((((a231 * a350) % 14999) % 13) - -167) - 5519) * 5) % 13) - -167);
    	a271 = ((a380 + a380) + -12);
    	a326 = (a343 - -7);
    	a330 = false;
    	a387 = ((((((a387 * a208) % 14999) * 2) % 25) + 91) + 2);
    	a10 = ((a326 + a383) - 12);
    	a236 = 1;
    	a233 = (((((((a233 * a385) % 14999) % 48) + 98) - -1) + 22187) + -22187);
    	a221 = 1;
    	a178 = ((((39 * 10) / 9) - -5769) + -5702);
    	a208 = ((((((a208 * a274) % 14999) * 2) * 1) % 94) - -246); 
    	System.out.println("P");
    } 
}
private  void calculateOutputm16(boolean input) {
    if((a327 <=  128) && (237 < a242) && (334 >= a242) && (a235==false) && (input==false) && (a10 == 1)) {
    	a62 -= (a62 - 20) < a62 ? 4 : 0;
    	cf = false;
    	a260 = (a299 + 3);
    	a153 = 0;
    	a159 = (((((((a242 * a242) % 14999) % 108) - -273) * 10) / 9) + 29); 
    	System.out.println("V");
    } 
    if((a231 <=  153) && (a340 == 2) && (input==false) && (a10 == 1) && (cf==false) && (237 < a242) && (a312==0) && (a322==0)) {
    	a62 -= (a62 - 20) < a62 ? 2 : 0;
    	cf = false;
    	a399 = false;
    	a227 = false;
    	a241 = (((((((a327 * a358) % 14999) / 5) - 12853) - 9301) % 96) + 37);
    	a271 = (a270 + 3);
    	a235 = false;
    	a381 = (a270 + -3);
    	a225 = ((((((a224 * a224) % 14999) % 38) - -196) + 15540) + -15538);
    	a355 = ((a270 - a210) + 5);
    	a336 = 1;
    	a328 = 1;
    	a243 = 1;
    	a159 = (((((a242 * a242) % 14999) + -463) / 5) - 28472);
    	a350 = (((((a241 * a241) * 2) * 1) % 97) - -138);
    	a387 = (((((((a350 * a225) % 14999) % 25) - -74) - -14) - 14907) - -14894);
    	a263 = ((a68 * a10) + 1);
    	a378 = (a291 - 2);
    	a276 = 1;
    	a299 = a289;
    	a256 = false;
    	a327 = ((((((a224 * a233) % 14999) * 2) / 5) % 54) - -183);
    	a368 = ((((((a368 * a387) % 14999) % 13) + 47) + 1) - 3);
    	a323 = false;
    	a373 = (((((((a209 * a228) % 14999) % 102) + 177) + -20) * 9) / 10);
    	a206 = false;
    	a48 = (a10 - -3);
    	a10 = ((a48 + a48) + -3);
    	a247 = false;
    	a329 = ((a337 + a343) + 2);
    	a286 = ((a378 + a362) + -9);
    	a273 = false;
    	a279 = false;
    	a312 = 1;
    	a208 = ((((((a358 * a298) % 14999) - 6074) + 35025) % 94) - -199);
    	a221 = 1;
    	a396 = (((((a241 * a241) % 72) + 95) * 1) * 1);
    	a339 = 1;
    	a238 = 1;
    	a309 = false;
    	a253 = (a333 - -4);
    	a274 = (((((((a274 * a231) % 14999) * 2) % 38) - 19) + -6520) + 6517);
    	a340 = (a367 + -1);
    	a231 = ((((((a224 * a241) % 14999) % 13) - -167) - 1) + 1);
    	a322 = 1;
    	a392 = ((a253 + a253) - 8);
    	a236 = 1;
    	a229 = 1;
    	a358 = (((((((a358 * a371) % 14999) % 74) - 68) + -43) * 9) / 10);
    	a246 = false;
    	a371 = (((((a241 * a361) * 1) - 1532) % 61) + -122);
    	a303 = 1;
    	a248 = true;
    	a314 = 1;
    	a345 = false;
    	a288 = ((((((a350 * a233) % 14999) + -12147) / 5) % 77) - -211);
    	a289 = a320;
    	a302 = false;
    	a201 = 1;
    	a224 = (((((((a224 * a225) % 14999) * 2) % 105) + 287) / 5) - -221); 
    	System.out.println("W");
    } 
}
private  void calculateOutputm17(boolean input) {
    if((a329 == 7) && (a246==false) && (a272==0) && (a329 == 7) && (a371 <=  -184) && (a10 == 1) && (cf==false) &&  (input==false)) {
    	a62 += (a62 + 20) > a62 ? 2 : 0;
    	cf = false;
    	a228 = ((((((a228 * a274) % 14999) % 100) - -217) - -2) + -1);
    	a10 = ((a205 + a352) - 4);
    	a333 = ((a400 * a68) + -82);
    	a352 = (a378 + 6);
    	a248 = false;
    	a81 = 0;
    	a322 = 1;
    	a345 = false;
    	a246 = false;
    	a293 = 1;
    	a224 = ((((((a224 * a231) % 14999) % 105) - -287) + 15743) + -15741);
    	a105 = true;
    	a368 = ((((((((a368 * a274) % 14999) + 5236) % 13) + 45) * 5) % 13) - -47);
    	a205 = (a320 + -2);
    	a329 = ((a210 - a68) - -13);
    	a124 = (((((34 * -31) / 10) / 5) + 4833) - 4814); 
    	System.out.println("V");
    } 
}
public  void calculateOutput(boolean input) {
 	cf = true;
    	if((a201==0) && (cf==false) && (a153==0) && (a284 <=  142) && (a243==0) && (a248==false) && (a303==0) && (a345==false)) {
    		calculateOutputm13(input);
    	} 
    	if((a238==0) && (a256==false) && (a238==0) && (a153==0) && (cf==false) && (a221==0) && (a368 <=  32) && (a243==0)) {
    		calculateOutputm14(input);
    	} 
    	if((a327 <=  128) && (a288 <=  133) && (cf==false) && (a153==0) && (a205 == 3) && (a221==0) && (a236==0) && (a308==0)) {
    		calculateOutputm15(input);
    	} 
    	if((a358 <=  -138) && (cf==false) && (a153==0) && (a221==0) && (a385 <=  100) && (a343 == 3) && (a208 <=  152) && (a390==0)) {
    		calculateOutputm16(input);
    	} 
    	if((cf==false) && (a153==0) && (a396 <=  23) && (a220==false) && (a253 == 5) && (a339==0) && (a399==false) && (a328==0)) {
    		calculateOutputm17(input);
    	} 
    
    errorCheck();
    if(cf==false)
    	throw new IllegalArgumentException("Current state has no transition for this input!");
}

public static void main() throws Exception 
	{
	     // init system and input reader
            Problem2_RERS2015 eca = new Problem2_RERS2015();
        int a=0;
	int x;
        int y;
         
        x = Cute.input.Integer();
        y = Cute.input.Integer();
		boolean input = Cute.input.Boolean();
			// main i/o-loop
            while(a<10) //Sanghu changed the bound from 10 to 1.
            {
            	
                try{
                	 if (x>199 && x>y){
           System.out.println("X is greater than 199 and also greater than y");
                	 eca.calculateOutput(input);
					 
				}
				
				if (x>299 && x<y){
            System.out.println("X is greater than 299 but  lesser than y");
		
			eca.calculateOutput(input);
        }
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
				
				a++;
	    	}
	}

}

//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
