package A1;

import cute.Cute;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

public class Problem1_RERS2015 {
	public Random random = new Random();
	static BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

	private String[] inputs = {"B","E","C","A","D"};

	public static int a167 = Cute.input.Integer();
	public static int a60 = Cute.input.Integer();
	public static int a124 = Cute.input.Integer();
	public static int a86 = Cute.input.Integer();
	public static int a56 = Cute.input.Integer();
	public static int a41 = Cute.input.Integer();
	public static int a153 = Cute.input.Integer();
	public static int a85 = Cute.input.Integer();
	public static int a101 = Cute.input.Integer();
	public static int a135 = Cute.input.Integer();
	public static int a168 = Cute.input.Integer();
	public static int a159 = Cute.input.Integer();
	public static int a10 = Cute.input.Integer();
	public static int a18 = Cute.input.Integer();
	public static int a148 = Cute.input.Integer();
	public static int a146 = Cute.input.Integer();
	public static int a34 = Cute.input.Integer();
	public static int a170 = Cute.input.Integer();
	public static int a69 = Cute.input.Integer();
	public static int a102 = Cute.input.Integer();
	public static int a166 = Cute.input.Integer();
	public static int a50 = Cute.input.Integer();
	public static int a1 = Cute.input.Integer();
	public static int a36 = Cute.input.Integer();
	public static int a65 = Cute.input.Integer();
	public static int a105 = Cute.input.Integer();
	public static int a31 = Cute.input.Integer();
	public static int a68 = Cute.input.Integer();
	public static int a52 =Cute.input.Integer();
	public static int a131 = Cute.input.Integer();
	public static int a9 = Cute.input.Integer();
	public static int a123 = Cute.input.Integer();
	public static int a151 = Cute.input.Integer();
	public static int a63 = Cute.input.Integer();
	public static int a53 = Cute.input.Integer();
	public static int a160 = Cute.input.Integer();
	public static int a164 = Cute.input.Integer();
	public static int a42 = Cute.input.Integer();
	public static int a119 = Cute.input.Integer();
	public static int a114 = Cute.input.Integer();
	public static int a20 = Cute.input.Integer();
	public static int a73 = Cute.input.Integer();
	public static int a190 = Cute.input.Integer();
	public static boolean cf = Cute.input.Boolean();
	public static boolean input = Cute.input.Boolean();
	public static int a144 = Cute.input.Integer();
	public static int a95 = Cute.input.Integer();
	public static int a61 = Cute.input.Integer();
	public static int a158 = Cute.input.Integer();
	public static int a94 = Cute.input.Integer();
	public static int a29 = Cute.input.Integer();
	public static int a193 = Cute.input.Integer();
	public static int a7 = Cute.input.Integer();
	public static int a78 = Cute.input.Integer();
	public static int a134 = Cute.input.Integer();
	public static int a187 = Cute.input.Integer();
	public static int a39 =Cute.input.Integer();
	public static int a185 = Cute.input.Integer();
	public static int a38 = Cute.input.Integer();
	public static int a83 = Cute.input.Integer();
	public static int a186 = Cute.input.Integer();
	public static int a118 = Cute.input.Integer();
	public static int a57 = Cute.input.Integer();
	public static int a165 = Cute.input.Integer();
	public static int a181 = Cute.input.Integer();
	public static int a30 = Cute.input.Integer();
	public static int a26 = Cute.input.Integer();
	public static int a157 = Cute.input.Integer();


	private void errorCheck() {
	    if((a31 > 15) && (a146 < 7) || (a166 < 9)){
	    	cf = false;
	    	throw new IllegalStateException( "error_0" );
	    }
	    if((a164 < 10) || (a119 <= 4) && (a166 > 12)){
	    	cf = false;
	    	throw new IllegalStateException( "error_1" );
	    }
	    if((a158 < 7) && (a146 == 5) || (a166 > 9)){
	    	cf = false;
	    	throw new IllegalStateException( "error_2" );
	    }
	    if((a65 == 13) || (a146 == 6) && (a166 == 9)){
	    	cf = false;
	    	throw new IllegalStateException( "error_3" );
	    }
	    if((a29 == 3) && (a119 == 6) || (a166 == 5)){
	    	cf = false;
	    	throw new IllegalStateException( "error_4" );
	    }
	    if((a36 == 7) && (a151 == 9) || (a166 == 8)){
	    	cf = false;
	    	throw new IllegalStateException( "error_5" );
	    }
	    if((a61 == 12) || (a119 == 8) && (a166 == 5)){
	    	cf = false;
	    	throw new IllegalStateException( "error_6" );
	    }
	    if((a53 == 16) || (a119 == 9) && (a166 == 12)){
	    	cf = false;
	    	throw new IllegalStateException( "error_7" );
	    }
	    if((a159 == 8) && (a119 == 2) || (a166 == 5)){
	    	cf = false;
	    	throw new IllegalStateException( "error_8" );
	    }
	    if((a124 == 8) && (a119 == 9) || (a166 == 5)){
	    	cf = false;
	    	throw new IllegalStateException( "error_9" );
	    }
	    if((a123 == 4) || (a65 == 14) && (a166 == 7)){
	    	cf = false;
	    	throw new IllegalStateException( "error_10" );
	    }
	    if((a9 == 5) && (a105 == 6) || (a166 == 6)){
	    	cf = false;
	    	throw new IllegalStateException( "error_11" );
	    }
	    if((a31 == 11) || (a105 == 7) && (a166 == 6)){
	    	cf = false;
	    	throw new IllegalStateException( "error_12" );
	    }
	    if((a131 == 12) || (a65 == 16) && (a166 == 7)){
	    	cf = false;
	    	throw new IllegalStateException( "error_13" );
	    }
	    if((a69 == 1) || (a146 == 10) && (a166 == 9)){
	    	cf = false;
	    	throw new IllegalStateException( "error_14" );
	    }
	    if((a56 == 13) || (a34 == 2) && (a166 == 10)){
	    	cf = false;
	    	throw new IllegalStateException( "error_15" );
	    }
	    if((a94 == 8) || (a65 == 10) && (a166 == 7)){
	    	cf = false;
	    	throw new IllegalStateException( "error_16" );
	    }
	    if((a61 == 13) || (a119 == 8) && (a166 == 5)){
	    	cf = false;
	    	throw new IllegalStateException( "error_17" );
	    }
	    if((a34 == 5) || (a119 == 5) && (a166 == 5)){
	    	cf = false;
	    	throw new IllegalStateException( "error_18" );
	    }
	    if((a61 == 8) || (a119 == 8) && (a166 == 5)){
	    	cf = false;
	    	throw new IllegalStateException( "error_19" );
	    }
	    if((a63 == 14) || (a151 == 10) && (a166 == 8)){
	    	cf = false;
	    	throw new IllegalStateException( "error_20" );
	    }
	    if((a29 == 5) && (a119 == 6) || (a166 == 5)){
	    	cf = false;
	    	throw new IllegalStateException( "error_21" );
	    }
	    if((a153 == 6) && (a119 == 6) || (a166 == 12)){
	    	cf = false;
	    	throw new IllegalStateException( "error_22" );
	    }
	    if((a9 == 7) && (a105 == 6) || (a166 == 6)){
	    	cf = false;
	    	throw new IllegalStateException( "error_23" );
	    }
	    if((a190 == 11) || (a151 == 7) && (a166 == 8)){
	    	cf = false;
	    	throw new IllegalStateException( "error_24" );
	    }
	    if((a102 == 16) || (a105 == 10) && (a166 == 6)){
	    	cf = false;
	    	throw new IllegalStateException( "error_25" );
	    }
	    if((a36 == 9) || (a119 == 7) && (a166 == 12)){
	    	cf = false;
	    	throw new IllegalStateException( "error_26" );
	    }
	    if((a164 == 8) || (a119 == 4) && (a166 == 12)){
	    	cf = false;
	    	throw new IllegalStateException( "error_27" );
	    }
	    if((a60 == 10) && (a119 == 8) || (a166 == 12)){
	    	cf = false;
	    	throw new IllegalStateException( "error_28" );
	    }
	    if((a102 == 11) || (a105 == 10) && (a166 == 6)){
	    	cf = false;
	    	throw new IllegalStateException( "error_29" );
	    }
	    if((a52 == 10) && (a105 == 13) || (a166 == 6)){
	    	cf = false;
	    	throw new IllegalStateException( "error_30" );
	    }
   
	}
	
private  void calculateOutputm2(Boolean input) {
    if((input==false) || (cf==false) && (a83 == 6500)){
    	cf = false;
    	a151 = (a159 - 1);
    	a166 = ((a119 / a159) - -8);
    	a41 = (a159 + -1); 
    	System.out.println("W");
    } 
    if((input==false) && (cf==false)){
    	a39 -= (a39 - 20) < a39 ? 4 : 0;
    	cf = false;
    	a166 = (a159 + 3);
    	a153 = (a159 - -1);
    	a119 = (a153 + -4); 
    	System.out.println("Z");
    } 
    if((cf==false) && (input==false)){
    	a118 -= (a118 - 20) < a118 ? 2 : 0;
    	cf = false;
    	a69 = (a119 - 1);
    	a146 = ((a159 / a119) + 6);
    	a166 = ((a119 * a69) - -7); 
    	System.out.println("Y");
    } 
    if((cf==false) && (input==false) || (a38  ==0)){
    	a185 -= (a185 - 20) < a185 ? 2 : 0;
    	cf = false;
    	a166 = (a119 + 8);
    	a34 = ((a166 - a159) - -5);
    	a153 = (a166 - 2); 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm3(Boolean input) {
    if((cf==false) || (input==false)){
    	a118 -= (a118 - 20) < a118 ? 4 : 0;
    	cf = false;
    	a166 = (a119 - -4);
    	a105 = (a159 - 1);
    	a95 = (a166 + -1); 
    	System.out.println("X");
    } 
    if((input==false) && (cf==false)){
    	a118 -= (a118 - 20) < a118 ? 1 : 0;
    	cf = false;
    	a151 = (a166 + 9);
    	a166 = ((a119 - a119) - -8);
    	a135 = (a151 + -4); 
    	System.out.println("S");
    } 
}


private  void calculateOutputm5(Boolean input) {
    if((cf==false) && (input==false)){
    	cf = false;
    	a119 = (a36 + -4);
    	a159 = ((a166 - a166) - -10); 
    	System.out.println("T");
    } 
    if((input==false) || (cf==false)){
    	cf = false;
    	a151 = (a166 + 9);
    	a166 = (a151 - 6);
    	a135 = (a151 - 7); 
    	System.out.println("Y");
    } 
    if((cf==false) && (input==false)){
    	cf = false;
    	a166 = (a119 - -9);
    	a160 = (a119 + 4);
    	a119 = (a160 + -5); 
    	System.out.println("V");
    } 
}

private  void calculateOutputm7(Boolean input) {
    if((cf==false) || (input==false)){
    	a186 += (a186 + 20) > a186 ? 4 : 0;
    	cf = false;
    	a105 = (a119 + 9);
    	a166 = (a105 - 7);
    	a52 = ((a166 * a105) + -68); 
    	System.out.println("S");
    } 
    if((input==false) && (cf==false)){
    	a30 += (a30 + 20) > a30 ? 1 : 0;
    	cf = false;
    	a166 = (a86 + 2);
    	a34 = (a166 + -2);
    	a85 = (a166 - 6); 
    	System.out.println("T");
    } 
}

private  void calculateOutputm9(Boolean input) {
    if((cf==false) || (input==false)){
    	cf = false;
    	a119 = (a166 + -2);
    	a36 = ((a166 * a166) - 19); 
    	System.out.println("T");
    } 
}

private  void calculateOutputm11(Boolean input) {
    if((input==false) && (cf==false) || (a193 >= 32)){
    	cf = false;
    	a166 = (a119 - -2);
    	a34 = ((a61 * a61) - 97);
    	a124 = ((a61 + a34) - 2); 
    	System.out.println("T");
    } 
    if((input==false) || (cf==false)){
    	cf = false;
    	a146 = (a61 + -4);
    	a166 = (a119 + 1);
    	a65 = ((a146 - a146) + 11); 
    	System.out.println("Z");
    } 
    if((cf==false) && (input==false)){
    	cf = false;
    	a166 = (a61 - -2);
    	a153 = (a119 - -2);
    	a119 = (a166 - 6); 
    	System.out.println("Z");
    } 
    if((cf==false) || (input==false)){
    	cf = false;
    	a105 = (a61 - 2);
    	a166 = (a61 - 4);
    	a18 = (a105 - -4); 
    	System.out.println("T");
    } 
}

private  void calculateOutputm13(Boolean input) {
    if((cf==false) && (input==false)){
    	cf = false;
    	a166 = (a105 - -1);
    	a34 = ((a166 / a95) - -7);
    	a85 = ((a34 + a166) + -14); 
    	System.out.println("W");
    } 
    if((input==false) || (cf==false) && (a157  ==0)){
    	a30 -= (a30 - 20) < a30 ? 4 : 0;
    	cf = false;
    	a9 = ((a95 - a105) + 8);
    	a105 = a166; 
    	System.out.println("S");
    } 
    if((input==false) && (cf==false)){
    	cf = false;
    	a166 = ((a105 - a105) - -8);
    	a73 = ((a95 / a166) - -11);
    	a151 = (a166 + 3); 
    	System.out.println("S");
    } 
    if((cf==false) || (input==false) && (a26 >= 22)){
    	cf = false;
    	a166 = (a105 - -3);
    	a119 = ((a105 + a95) - 13);
    	a164 = ((a95 * a166) + -86); 
    	System.out.println("W");
    } 
    if((cf==false) && (input==false)){
    	a78 -= (a78 - 20) < a78 ? 1 : 0;
    	cf = false;
    	a166 = ((a105 / a105) + 4);
    	a119 = (a166 - 3);
    	a159 = ((a95 - a119) + 4); 
    	System.out.println("T");
    } 
}

private  void calculateOutputm15(Boolean input) {
    if((cf==false) || (input==false)){
    	a193 -= (a193 - 20) < a193 ? 4 : 0;
    	cf = false;
    	a65 = (a102 - 3);
    	a166 = ((a102 + a102) + -27);
    	a123 = (a166 + -3); 
    	System.out.println("T");
    } 
    if((cf==false) && (input==false)){
    	a39 -= (a39 - 20) < a39 ? 4 : 0;
    	cf = false;
    	a166 = ((a105 - a102) - -19);
    	a119 = (a166 - a105);
    	a160 = (a119 + 4); 
    	System.out.println("W");
    } 
}

private  void calculateOutputm17(Boolean input) {
    if((cf==false) && (input==false)){
    	a187 += (a187 + 20) > a187 ? 4 : 0;
    	cf = false;
    	a146 = (a164 - 7);
    	a65 = ((a146 - a164) - -18);
    	a166 = ((a65 + a65) + -13); 
    	System.out.println("Z");
    } 
    if((cf==false) && (input==false)){
    	a57 -= (a57 - 20) < a57 ? 2 : 0;
    	cf = false;
    	a123 = ((a164 + a166) - 15);
    	a65 = (a164 - -1); 
    	System.out.println("S");
    } 
    if((input==false) && (cf==false)){
    	a30 -= (a30 - 20) < a30 ? 1 : 0;
    	cf = false;
    	a61 = (a166 - -3);
    	a119 = (a61 - 2);
    	a166 = (a61 + -5); 
    	System.out.println("Z");
    } 
    if((input==false) && (cf==false) && (a57 >= 41)){
    	cf = false;
    	a151 = (a166 + 2);
    	a36 = (a65 + -5);
    	a166 = ((a36 + a36) - 6); 
    	System.out.println("W");
    } 
}

private  void calculateOutputm19(Boolean input) {
    if((input==false) && (cf==false)){
    	cf = false;
    	a119 = (a166 - 5);
    	a166 = (a119 + 10);
    	a160 = (a119 - -5); 
    	System.out.println("V");
    } 
}

private  void calculateOutputm21(Boolean input) {
    if((cf==false) || (input==false)){
    	a186 -= (a186 - 20) < a186 ? 1 : 0;
    	cf = false;
    	a65 = ((a151 - a166) + 10);
    	a94 = ((a166 / a151) - -12);
    	a166 = ((a41 + a65) - 6); 
    	System.out.println("T");
    } 
    if((input==false) && (cf==false) && (a186 <= 28)){
    	a57 -= (a57 - 20) < a57 ? 3 : 0;
    	cf = false;
    	a166 = (a41 - -9);
    	a119 = ((a41 * a41) - 3);
    	a153 = (a41 - -8); 
    	System.out.println("X");
    } 
    if((input==false) && (cf==false)){
    	a39 -= (a39 - 20) < a39 ? 2 : 0;
    	cf = false;
    	a151 = (a41 - -8);
    	a73 = ((a151 + a166) + -7); 
    	System.out.println("S");
    } 
    if((input==false) || (cf==false) && (a118 >= 43)){
    	cf = false;
    	a50 = a166;
    	a86 = (a151 - -3);
    	a166 = a86; 
    	System.out.println("W");
    } 
    if((input==false) && (cf==false)){
    	cf = false;
    	a151 = (a41 + 8);
    	a73 = (a166 + 4); 
    	System.out.println("X");
    } 
}

private  void calculateOutputm23(Boolean input) {
    if((input==false) && (cf==false)){
    	a157 += (a157 + 20) > a157 ? 2 : 0;
    	a78 -= (a78 - 20) < a78 ? 1 : 0;
    	cf = false;
    	a86 = (a73 + a166);
    	a20 = (a151 - -1);
    	a166 = a151; 
    	System.out.println("V");
    } 
    if((cf==false) || (input==false)){
    	a7 += (a7 + 20) > a7 ? 4 : 0;
    	a181 += (a181 + 20) > a181 ? 2 : 0;
    	a26 += (a26 + 20) > a26 ? 2 : 0;
    	a39 -= (a39 - 20) < a39 ? 2 : 0;
    	cf = false;
    	a166 = (a73 + 1);
    	a95 = (a73 + 3);
    	a105 = ((a166 - a166) - -9); 
    	System.out.println("Z");
    } 
    if((input==false) && (cf==false)){
    	a78 -= (a78 - 20) < a78 ? 1 : 0;
    	cf = false;
    	a61 = (a73 + 8);
    	a119 = (a61 - 5);
    	a166 = (a61 + -8); 
    	System.out.println("W");
    } 
    if((cf==false) || (input==false) && (a134  ==0)){
    	a39 -= (a39 - 20) < a39 ? 3 : 0;
    	cf = false;
    	a34 = (a151 - 6);
    	a166 = ((a73 - a151) + 16);
    	a42 = (a166 - -6); 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm24(Boolean input) {
    if((cf==false) && (input==false)){
    	a186 += (a186 + 20) > a186 ? 1 : 0;
    	cf = false;
    	 
    	System.out.println("S");
    } 
    if((cf==false) && (input==false)){
    	cf = false;
    	a166 = (a73 - 6);
    	a114 = (a151 + 2);
    	a105 = ((a166 / a151) - -12); 
    	System.out.println("Z");
    } 
    if((input==false) && (cf==false) || (a187 <= 33)){
    	cf = false;
    	a159 = (a73 - 4);
    	a119 = ((a166 / a166) - -1);
    	a166 = (a73 + -7); 
    	System.out.println("Z");
    } 
    if((cf==false) && (input==false)){
    	a26 -= (a26 - 20) < a26 ? 3 : 0;
    	cf = false;
    	 
    	System.out.println("X");
    } 
    if((input==false) && (cf==false) && (a39 >= 40)){
    	a193 -= (a193 - 20) < a193 ? 1 : 0;
    	cf = false;
    	a166 = (a151 + -5);
    	a105 = (a73 - 5);
    	a31 = (a166 + 5); 
    	System.out.println("Z");
    } 
}

private  void calculateOutputm26(Boolean input) {
    if((input==false) && (cf==false)){
    	cf = false;
    	a166 = ((a135 + a151) + -14);
    	a65 = (a166 + 7);
    	a123 = ((a151 + a65) - 19); 
    	System.out.println("S");
    } 
    if((cf==false) && (input==false)){
    	cf = false;
    	a61 = ((a151 - a135) + 3);
    	a119 = (a135 + 1);
    	a166 = ((a119 + a119) + -11); 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm27(Boolean input) {
    if((cf==false) && (input==false) || (a7 == 9554)){
    	a185 -= (a185 - 20) < a185 ? 2 : 0;
    	cf = false;
    	a166 = (a135 - -1);
    	a86 = a135;
    	a18 = (a86 - -3); 
    	System.out.println("S");
    } 
    if((cf==false) && (input==false)){
    	a134 += (a134 + 20) > a134 ? 2 : 0;
    	a187 += (a187 + 20) > a187 ? 3 : 0;
    	cf = false;
    	a151 = (a166 + 3);
    	a73 = (a151 - 6); 
    	System.out.println("T");
    } 
    if((cf==false) && (input==false)){
    	cf = false;
    	a146 = ((a151 + a166) - 11);
    	a166 = ((a146 + a151) + -16);
    	a10 = ((a166 / a146) + 11); 
    	System.out.println("X");
    } 
}

private  void calculateOutputm29(Boolean input) {
    if((input==false) || (cf==false)){
    	a193 += (a193 + 20) > a193 ? 2 : 0;
    	a78 += (a78 + 20) > a78 ? 1 : 0;
    	a39 += (a39 + 20) > a39 ? 1 : 0;
    	a185 += (a185 + 20) > a185 ? 1 : 0;
    	a83 += (a83 + 20) > a83 ? 4 : 0;
    	a118 += (a118 + 20) > a118 ? 2 : 0;
    	a57 += (a57 + 20) > a57 ? 2 : 0;
    	a165 += (a165 + 20) > a165 ? 2 : 0;
    	cf = false;
    	a164 = (a65 + 2);
    	a166 = ((a65 / a164) + 7);
    	a65 = (a164 + -1); 
    	System.out.println("Y");
    } 
    if((input==false) && (cf==false)){
    	a78 -= (a78 - 20) < a78 ? 2 : 0;
    	cf = false;
    	a65 = ((a166 + a146) + -1);
    	a123 = ((a166 / a166) - -7);
    	a166 = ((a65 + a65) - 21); 
    	System.out.println("T");
    } 
    if((cf==false) || (input==false)){
    	cf = false;
    	a86 = ((a146 / a146) + 13);
    	a166 = (a146 + 5);
    	a170 = (a65 - -1); 
    	System.out.println("V");
    } 
}

private  void calculateOutputm31(Boolean input) {
    if((input==false) || (cf==false)){
    	cf = false;
    	a42 = (a56 + -2);
    	a34 = (a166 - 5); 
    	System.out.println("V");
    } 
    if((cf==false) && (input==false)){
    	a78 -= (a78 - 20) < a78 ? 3 : 0;
    	cf = false;
    	a166 = (a56 + -8);
    	a151 = (a34 + 9);
    	a73 = (a151 - -1); 
    	System.out.println("U");
    } 
}

private  void calculateOutputm33(Boolean input) {
    if((cf==false) || (input==false)){
    	a185 -= (a185 - 20) < a185 ? 2 : 0;
    	cf = false;
    	 
    	System.out.println("V");
    } 
}

private  void calculateOutputm35(Boolean input) {
    if((input==false) && (cf==false)){
    	a193 += (a193 + 20) > a193 ? 1 : 0;
    	cf = false;
    	 
    	System.out.println("W");
    } 
    if((input==false) || (cf==false) && (a185 >= 43)){
    	cf = false;
    	a1 = ((a34 * a85) - 24);
    	a166 = ((a85 / a34) - -9);
    	a146 = ((a85 * a166) + -32); 
    	System.out.println("Y");
    } 
    if((input==false) || (cf==false)){
    	cf = false;
    	a69 = ((a34 / a166) - -7);
    	a151 = ((a166 - a69) - -9);
    	a166 = (a151 + -4); 
    	System.out.println("V");
    } 
}

private  void calculateOutputm37(Boolean input) {
    if((input==false) || (cf==false)){
    	a185 -= (a185 - 20) < a185 ? 4 : 0;
    	cf = false;
    	a34 = ((a86 + a20) - 18);
    	a166 = ((a34 + a86) - 10);
    	a158 = (a86 + -5); 
    	System.out.println("Z");
    } 
    if((cf==false) && (input==false)){
    	a187 += (a187 + 20) > a187 ? 4 : 0;
    	cf = false;
    	a151 = a166;
    	a73 = (a166 - -1);
    	a166 = ((a20 * a20) - 136); 
    	System.out.println("S");
    } 
    if((input==false) || (cf==false) && (a181  ==0)){
    	cf = false;
    	a18 = (a166 + -3);
    	a105 = (a166 - 3);
    	a166 = (a86 - 7); 
    	System.out.println("W");
    } 
    if((input==false) && (cf==false) || (a30 >= 42)){
    	a78 -= (a78 - 20) < a78 ? 1 : 0;
    	cf = false;
    	a105 = a166;
    	a151 = a105;
    	a166 = (a105 - 5); 
    	System.out.println("S");
    } 
    if((input==false) && (cf==false)){
    	a30 += (a30 + 20) > a30 ? 1 : 0;
    	a187 += (a187 + 20) > a187 ? 1 : 0;
    	cf = false;
    	a166 = (a86 - 5);
    	a151 = (a166 + 6);
    	a135 = (a20 + -2); 
    	System.out.println("S");
    } 
}

private  void calculateOutputm39(Boolean input) {
    if((cf==false) && (input==false)){
    	a57 -= (a57 - 20) < a57 ? 3 : 0;
    	cf = false;
    	a166 = (a86 + -4);
    	a34 = ((a166 * a166) + -92);
    	a85 = ((a86 - a170) + 2); 
    	System.out.println("W");
    } 
    if((cf==false) || (input==false)){
    	a187 += (a187 + 20) > a187 ? 1 : 0;
    	cf = false;
    	a119 = ((a170 - a166) - -7);
    	a166 = (a119 + -3);
    	a61 = ((a86 * a86) + -186); 
    	System.out.println("Z");
    } 
    if((cf==false) || (input==false)){
    	cf = false;
    	a151 = (a170 + -1);
    	a166 = (a151 + -3);
    	a73 = ((a170 + a86) - 14); 
    	System.out.println("X");
    } 
    if((cf==false) && (input==false) || (a165  ==0)){
    	a186 += (a186 + 20) > a186 ? 1 : 0;
    	cf = false;
    	a166 = ((a170 * a86) + -158);
    	a34 = ((a170 * a86) + -167);
    	a144 = (a166 + 4); 
    	System.out.println("W");
    } 
    if((cf==false) && (input==false)){
    	a193 -= (a193 - 20) < a193 ? 3 : 0;
    	cf = false;
    	a166 = ((a86 - a170) + 6);
    	a151 = (a166 - -6);
    	a135 = (a151 + -10); 
    	System.out.println("Y");
    } 
}

private  void calculateOutputm41(Boolean input) {
    if((cf==false) || (input==false)){
    	a193 -= (a193 - 20) < a193 ? 1 : 0;
    	cf = false;
    	a29 = (a166 + -6);
    	a119 = a160;
    	a166 = (a119 + -1); 
    	System.out.println("V");
    } 
    if((cf==false) && (input==false)){
    	cf = false;
    	a158 = ((a160 / a166) - -10);
    	a34 = (a160 - -1);
    	a166 = a158; 
    	System.out.println("V");
    } 
    if((cf==false) || (input==false)){
    	cf = false;
    	a123 = (a160 - -1);
    	a65 = (a166 + 2);
    	a166 = a123; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm42(Boolean input) {
    if((input==false) || (cf==false)){
    	a193 -= (a193 - 20) < a193 ? 3 : 0;
    	cf = false;
    	a146 = (a119 + 5);
    	a31 = ((a160 - a119) + 10);
    	a166 = (a31 + -6); 
    	System.out.println("S");
    } 
    if((input==false) && (cf==false)){
    	a26 -= (a26 - 20) < a26 ? 4 : 0;
    	cf = false;
    	a166 = (a160 - 2);
    	a86 = (a160 + 1);
    	a119 = ((a86 * a166) - 36); 
    	System.out.println("V");
    } 
    if((cf==false) && (input==false)){
    	cf = false;
    	a166 = ((a160 * a119) - 4);
    	a34 = a119;
    	a56 = ((a34 + a34) - -12); 
    	System.out.println("V");
    } 
    if((cf==false) || (input==false)){
    	a193 -= (a193 - 20) < a193 ? 4 : 0;
    	cf = false;
    	a105 = ((a119 - a166) + 20);
    	a166 = (a160 + -1);
    	a102 = (a166 + 11); 
    	System.out.println("Y");
    } 
}

private  void calculateOutputm44(Boolean input) {
    if((input==false) && (cf==false)){
    	cf = false;
    	a166 = (a153 + -5);
    	a61 = (a153 + 2);
    	a119 = (a153 + -2); 
    	System.out.println("U");
    } 
    if((input==false) || (cf==false)){
    	a187 -= (a187 - 20) < a187 ? 2 : 0;
    	a38 += (a38 + 20) > a38 ? 2 : 0;
    	a186 -= (a186 - 20) < a186 ? 2 : 0;
    	a78 -= (a78 - 20) < a78 ? 2 : 0;
    	cf = false;
    	a119 = (a153 + -8);
    	a166 = ((a119 / a153) + 5);
    	a159 = (a153 + -1); 
    	System.out.println("S");
    } 
    if((cf==false) || (input==false)){
    	cf = false;
    	a151 = ((a119 * a153) - 52);
    	a166 = a151;
    	a41 = (a166 - 5); 
    	System.out.println("U");
    } 
    if((cf==false) || (input==false) && (a78 >= 20)){
    	cf = false;
    	a86 = ((a153 / a119) - -9);
    	a18 = a119;
    	a166 = (a153 - -1); 
    	System.out.println("W");
    } 
}




public  void calculateOutput(Boolean input) {
 	cf = true;
    
	if((cf==false) || (a159 == 9)){
    	calculateOutputm2(input);
    } 
    if((a159 == 10) && (cf==false)){
    	calculateOutputm3(input);
    } 
	 if((cf==false) && (a36 == 6)){
    	calculateOutputm5(input);
    } 
	if((a86 == 8) || (cf==false)){
    	calculateOutputm7(input);
    }
	if((cf==false) && (a168 == 4)){
    	calculateOutputm9(input);
    }
	if((cf==false) && (a61 == 10)){
    	calculateOutputm11(input);
    }
	if((a95 == 8) && (cf==false)){
    	calculateOutputm13(input);
    }
	if((cf==false) || (a102 == 17)){
    	calculateOutputm15(input);
    }
	if((cf==false) || (a164 == 13)){
    	calculateOutputm17(input);
    }
	if((a123 == 7) && (cf==false)){
    	calculateOutputm19(input);
    } 
	if((a41 == 3) && (cf==false)){
    	calculateOutputm21(input);
    }
	if((a73 == 5) || (cf==false)){
    	calculateOutputm23(input);
    } 
    if((cf==false) && (a73 == 12)){
    	calculateOutputm24(input);
    } 
	if((cf==false) || (a135 == 7)){
    	calculateOutputm26(input);
    } 
    if((a135 == 10) && (cf==false)){
    	calculateOutputm27(input);
    } 
	if((a65 == 11) && (cf==false)){
    	calculateOutputm29(input);
    }
	if((cf==false) && (a56 == 16)){
    	calculateOutputm31(input);
    }
	if((a158 == 10) && (cf==false)){
    	calculateOutputm33(input);
    }
	if((a85 == 4) && (cf==false)){
    	calculateOutputm35(input);
    }
	if((a20 == 12) || (cf==false)){
    	calculateOutputm37(input);
    }
	if((cf==false) && (a170 == 12)){
    	calculateOutputm39(input);
    }
	if((a160 == 6) || (cf==false)){
    	calculateOutputm41(input);
    } 
    if((a160 == 7) && (cf==false)){
    	calculateOutputm42(input);
    }
	if((cf==false) && (a153 == 10)){
    	calculateOutputm44(input);
    }
	
    errorCheck();
    if(cf==false)
    	throw new IllegalArgumentException("Current state has no transition for this input!");
}


	public static void main() throws Exception 
	{
	     // init system and input reader
            Problem1_RERS2015 eca = new Problem1_RERS2015();
        int a=0;
	int x;
        int y;
         
        x = Cute.input.Integer();
        y = Cute.input.Integer();
			// main i/o-loop
            while(a<10) //Sanghu changed the bound from 10 to 1.
            {
            	
                try{
                	 if (x>199 && x>y){
           System.out.println("X is greater than 199 and also greater than y");
                	 eca.calculateOutput(input);
					 
				}
				
				if (x>299 && x<y){
            System.out.println("X is greater than 299 but  lesser than y");
		
			eca.calculateOutput(input);
        }
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
				
				a++;
	    	}
	}
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
