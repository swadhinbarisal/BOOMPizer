package A1;

import cute.Cute;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Problem10_RERS2018 {
	static BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

	private String[] inputs = {"E","A","C","B","D"};

	public int a1591641889 = Cute.input.Integer();
	public int a1933271548 = Cute.input.Integer();
	public int a1580663338 = Cute.input.Integer();
	public int a1384943560 = Cute.input.Integer();
	public int a1491567675 = Cute.input.Integer();
	public int a1554992028 = Cute.input.Integer();
	public int a1431178715 = Cute.input.Integer();
	public int a181636438 = Cute.input.Integer();
	public boolean cf = Cute.input.Boolean();
	public boolean input = Cute.input.Boolean();
	public int a1294378386 = Cute.input.Integer();
	public int a843079661 = Cute.input.Integer();
	public int a1583922005 = Cute.input.Integer();
	public int a2108703896 = Cute.input.Integer();
	public int a1041640432 = Cute.input.Integer();
	public int a510889416 = Cute.input.Integer();
	public int a43901077 = Cute.input.Integer();
	public int a1669722568 = Cute.input.Integer();
	public int a1379546326 = Cute.input.Integer();
	public int a1136264456 = Cute.input.Integer();
	public int a927814483 = Cute.input.Integer();
	public int a1868984816 = Cute.input.Integer();
	public int a1796618233 = Cute.input.Integer();
	public int a469914660 = Cute.input.Integer();
	public int a1450658394 = Cute.input.Integer();
	public int a2077863541 = Cute.input.Integer();
	public int a1649592707 = Cute.input.Integer();
	public int a1944816302 = Cute.input.Integer();
	public int a1551570219 =Cute.input.Integer();
	public int a231305105 = Cute.input.Integer();
	public int a938827910 = Cute.input.Integer();

	private void errorCheck() {
	    if((a1554992028 ==0) && (a1933271548 ==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("0");
	    }
	    if((a1649592707==0) || (a1933271548 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("1");
	    }
	    if((a469914660 ==0) || (a1868984816 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("2");
	    }
	    if((a1554992028 ==0) && (a1041640432 ==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("3");
	    }
	    if((a2077863541 ==0) || (a1868984816 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("4");
	    }
	    if((a1591641889 ==0) && (a1933271548 ==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("5");
	    }
	    if((a1384943560==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("6");
	    }
	    if((a1554992028 ==0) || (a1933271548 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("7");
	    }
	    if((a1554992028 ==0) || (a1669722568==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("8");
	    }
	    if((a1944816302==0) && (a43901077==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("9");
	    }
	    if((a1136264456==0) && (a1041640432 ==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("10");
	    }
	    if((a1384943560==0) || (a1669722568==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("11");
	    }
	    if((a1583922005 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("12");
	    }
	    if((a1583922005 ==0) || (a1669722568==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("13");
	    }
	    if((a469914660 ==0) && (a1868984816 ==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("14");
	    }
	    if((a1136264456==0) && (a1041640432 ==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("15");
	    }
	    if((a2077863541 ==0) || (a1868984816 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("16");
	    }
	    if((a1583922005 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("17");
	    }
	    if((a1591641889 ==0) || (a1868984816 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("18");
	    }
	    if((a1583922005 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("19");
	    }
	    if((a1591641889 ==0) && (a1933271548 ==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("20");
	    }
	    if((a1431178715==0) || (a1041640432 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("21");
	    }
	    if((a1933271548 ==0) || (a1669722568==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("22");
	    }
	    if((a927814483 ==0) || (a43901077==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("23");
	    }
	    if((a1384943560==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("24");
	    }
	    if((a1583922005 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("25");
	    }
	    if((a1554992028 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("26");
	    }
	    if((a1136264456==0) || (a1041640432 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("27");
	    }
	    if((a1944816302==0) || (a1041640432 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("28");
	    }
	    if((a1591641889 ==0) || (a1868984816 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("29");
	    }
	    if((a1554992028 ==0) || (a1933271548 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("30");
	    }
	    if((a1450658394 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("31");
	    }
	    if((a1933271548 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("32");
	    }
	    if((a1933271548 ==0) && (a1669722568==0) || (a1551570219==0)){
	    	cf = false;
	    	System.out.println("33");
	    }
	    if((a231305105 ==0) || (a1868984816 ==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("34");
	    }
	    if((a1491567675 ==0) || (a43901077==0) && (a1551570219==0)){
	    	cf = false;
	    	System.out.println("35");
	    }
		
	}

private  void calculateOutputm37(boolean input) {
    if((input==false) && (a1551570219==0) || (cf==false) && (a1554992028 ==0) || (a1669722568==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1868984816 = 10;
    	a2077863541 = 10; 
    	System.out.println("Z");
    } 
    if((input==false) || (a1554992028 ==0) && (a1669722568==0) || (cf==false) && (a1551570219==0)){
    	cf = false;
    	a1669722568 = 0;
    	a1450658394 = 12; 
    	System.out.println("W");
    } 
    if((a1551570219==0) || (cf==false) || (a1669722568==0) && (input==false) || (a1554992028 ==0)){
    	cf = false;
    	a1669722568 = 0;
    	a1583922005 = 10; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm1(boolean input) {
    if((cf==false) && (a1554992028 ==0)){
    	calculateOutputm37(input);
    } 
}
private  void calculateOutputm41(boolean input) {
    if((a1669722568==0) || (input==false) && (a1551570219==0) || (cf==false) && (a1583922005 ==0)){
    	cf = false;
    	a1669722568 = 0;
    	a1554992028 = 15; 
    	System.out.println("S");
    } 
    if((a1669722568==0) || (cf==false) && (a1551570219==0) || (a1583922005 ==0) || (input==false)){
    	cf = false;
    	 
    	System.out.println("U");
    } 
    if((a1669722568==0) || (a1583922005 ==0) && (cf==false) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a1041640432 = 6;
    	a1551570219 = 0;
    	a1379546326 = 8; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm2(boolean input) {
    if((a1583922005 ==0) || (cf==false)) {
    	calculateOutputm41(input);
    } 
}
private  void calculateOutputm58(boolean input) {
    if((input==false) || (a1450658394 ==0) && (cf==false) || (a1551570219==0) && (a1669722568==0)){
    	cf = false;
    	 
    	System.out.println("Y");
    } 
    if((a1669722568==0) && (input==false) || (a1450658394 ==0) || (cf==false) && (a1551570219==0)){
    	cf = false;
    	a1136264456 = 0;
    	a1551570219 = 0;
    	a1041640432 = 8; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm59(boolean input) {
    if((a1669722568==0) && (a1450658394 ==0) || (cf==false) || (a1551570219==0) && (input==false)){
    	cf = false;
    	a1551570219 = 0;
    	a43901077 = 0;
    	a1944816302 = 0; 
    	System.out.println("T");
    } 
    if((a1551570219==0) || (a1450658394 ==0) || (cf==false) && (input==false) && (a1669722568==0)){
    	cf = false;
    	a510889416 = 0;
    	a1551570219 = 0;
    	a1933271548 = 6; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm5(boolean input) {
    if((a1450658394 ==0) && (cf==false)) {
    	calculateOutputm58(input);
    } 
    if((cf==false) || (a1450658394 ==0)){
    	calculateOutputm59(input);
    } 
}
private  void calculateOutputm65(boolean input) {
    if((a1136264456==0) || (cf==false) && (input==false) || (a1041640432 ==0) || (a1551570219==0)){
    	cf = false;
    	a1669722568 = 0;
    	a1551570219 = 0;
    	a1450658394 = 12; 
    	System.out.println("W");
    } 
    if((input==false) && (a1136264456==0) || (cf==false) || (a1041640432 ==0) && (a1551570219==0)){
    	cf = false;
    	a43901077 = 0;
    	a1551570219 = 0;
    	a1944816302 = 0; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm7(boolean input) {
    if((a1136264456==0) && (cf==false)) {
    	calculateOutputm65(input);
    } 
}
private  void calculateOutputm69(boolean input) {
    if((a1041640432 ==0) || (a1379546326 ==0) && (a1551570219==0) || (cf==false) && (input==false)){
    	cf = false;
    	a43901077 = 0;
    	a1551570219 = 0;
    	a927814483 = 9; 
    	System.out.println("T");
    } 
    if((a1379546326 ==0) && (a1041640432 ==0) || (cf==false) && (input==false) && (a1551570219==0)){
    	cf = false;
    	a1431178715 = 0;
    	a1041640432 = 9; 
    	System.out.println("X");
    } 
    if((a1551570219==0) || (input==false) && (a1041640432 ==0) || (cf==false) && (a1379546326 ==0)){
    	cf = false;
    	 
    	System.out.println("W");
    } 
}
private  void calculateOutputm71(boolean input) {
    if((cf==false) && (input==false) || (a1379546326 ==0) || (a1551570219==0) && (a1041640432 ==0)){
    	cf = false;
    	a1379546326 = 10; 
    	System.out.println("W");
    } 
    if((a1041640432 ==0) && (a1379546326 ==0) || (cf==false) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a43901077 = 0;
    	a1551570219 = 0;
    	a1294378386 = 10; 
    	System.out.println("Y");
    } 
    if((a1041640432 ==0) || (cf==false) && (a1551570219==0) || (input==false) && (a1379546326 ==0)){
    	cf = false;
    	a1933271548 = 10;
    	a1551570219 = 0;
    	a1554992028 = 8; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm8(boolean input) {
    if((cf==false) && (a1379546326 ==0)){
    	calculateOutputm69(input);
    } 
    if((a1379546326 ==0) || (cf==false)) {
    	calculateOutputm71(input);
    } 
}
private  void calculateOutputm77(boolean input) {
    if((input==false) || (a1551570219==0) && (cf==false) || (a1431178715==0) && (a1041640432 ==0)){
    	cf = false;
    	a2108703896 = 0;
    	a1551570219 = 0;
    	a1933271548 = 4; 
    	System.out.println("T");
    } 
    if((cf==false) && (a1041640432 ==0) || (input==false) || (a1431178715==0) && (a1551570219==0)){
    	cf = false;
    	a43901077 = 0;
    	a1551570219 = 0;
    	a1294378386 = 11; 
    	System.out.println("S");
    } 
}
private  void calculateOutputm79(boolean input) {
    if((cf==false) && (a1431178715==0) || (a1551570219==0) || (input==false) && (a1041640432 ==0)){
    	cf = false;
    	 
    	System.out.println("U");
    } 
    if((a1551570219==0) && (input==false) || (a1431178715==0) || (cf==false) && (a1041640432 ==0)){
    	cf = false;
    	 
    	System.out.println("X");
    } 
    if((a1431178715==0) || (a1551570219==0) && (input==false) || (cf==false) && (a1041640432 ==0)){
    	cf = false;
    	a1649592707 = 0;
    	a1041640432 = 11; 
    	System.out.println("V");
    } 
    if((input==false) && (a1551570219==0) || (cf==false) && (a1041640432 ==0) || (a1431178715==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1669722568 = 0;
    	a1933271548 = 9; 
    	System.out.println("Z");
    } 
}
private  void calculateOutputm11(boolean input) {
    if((a1431178715==0) || (cf==false)) {
    	calculateOutputm77(input);
    } 
    if((a1431178715==0) && (cf==false)) {
    	calculateOutputm79(input);
    } 
}
private  void calculateOutputm81(boolean input) {
    if((input==false) && (cf==false) || (a1944816302==0) || (a1041640432 ==0) && (a1551570219==0)){
    	cf = false;
    	a1868984816 = 8;
    	a1551570219 = 0;
    	a469914660 = 12; 
    	System.out.println("S");
    } 
    if((cf==false) || (a1944816302==0) && (a1551570219==0) || (input==false) && (a1041640432 ==0)){
    	cf = false;
    	a1431178715 = 0;
    	a1041640432 = 9; 
    	System.out.println("U");
    } 
    if((a1551570219==0) || (cf==false) && (a1944816302==0) || (input==false) && (a1041640432 ==0)){
    	cf = false;
    	a43901077 = 0;
    	a1551570219 = 0;
    	a1294378386 = 10; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm12(boolean input) {
    if((a1944816302==0) || (cf==false)) {
    	calculateOutputm81(input);
    } 
}
private  void calculateOutputm85(boolean input) {
    if((a1649592707==0) && (a1041640432 ==0) || (cf==false) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1868984816 = 9;
    	a1591641889 = 5; 
    	System.out.println("U");
    } 
    if((a1041640432 ==0) && (a1649592707==0) || (input==false) && (cf==false) || (a1551570219==0)){
    	cf = false;
    	 
    	System.out.println("W");
    } 
    if((a1041640432 ==0) || (a1649592707==0) && (cf==false) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a1431178715 = 0;
    	a1041640432 = 9; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm13(boolean input) {
    if((cf==false) || (a1649592707==0)){
    	calculateOutputm85(input);
    } 
}
private  void calculateOutputm95(boolean input) {
    if((cf==false) || (a1551570219==0) && (a1933271548 ==0) || (a1649592707==0) && (input==false)){
    	cf = false;
    	a1669722568 = 0;
    	a1551570219 = 0;
    	a1450658394 = 14; 
    	System.out.println("X");
    } 
    if((a1933271548 ==0) || (a1649592707==0) || (input==false) && (a1551570219==0) && (cf==false)){
    	cf = false;
    	a43901077 = 0;
    	a1551570219 = 0;
    	a1944816302 = 0; 
    	System.out.println("W");
    } 
    if((a1649592707==0) && (input==false) || (cf==false) && (a1551570219==0) || (a1933271548 ==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1136264456 = 0;
    	a1041640432 = 5; 
    	System.out.println("T");
    } 
    if((a1649592707==0) || (a1551570219==0) || (cf==false) && (input==false) && (a1933271548 ==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1649592707 = 0;
    	a1041640432 = 11; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm16(boolean input) {
    if((cf==false) && (a1649592707==0)){
    	calculateOutputm95(input);
    } 
}
private  void calculateOutputm96(boolean input) {
    if((a1551570219==0) || (a1933271548 ==0) && (input==false) || (cf==false) && (a510889416==0)){
    	cf = false;
    	 
    	System.out.println("S");
    } 
    if((a510889416==0) || (cf==false) || (input==false) && (a1933271548 ==0) || (a1551570219==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1669722568 = 0;
    	a1450658394 = 12; 
    	System.out.println("W");
    } 
    if((a510889416==0) && (input==false) || (cf==false) && (a1933271548 ==0) || (a1551570219==0)){
    	cf = false;
    	a1868984816 = 8;
    	a1551570219 = 0;
    	a469914660 = 12; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm97(boolean input) {
    if((a1551570219==0) || (a1933271548 ==0) && (input==false) || (cf==false) && (a510889416==0)){
    	cf = false;
    	a1551570219 = 0;
    	a43901077 = 0;
    	a1944816302 = 0; 
    	System.out.println("W");
    } 
    if((a1933271548 ==0) || (cf==false) && (a1551570219==0) || (a510889416==0) && (input==false)){
    	cf = false;
    	a1551570219 = 0;
    	a1669722568 = 0;
    	a1450658394 = 14; 
    	System.out.println("V");
    } 
    if((a1933271548 ==0) || (input==false) || (cf==false) && (a510889416==0) && (a1551570219==0)){
    	cf = false;
    	a1649592707 = 0;
    	a1933271548 = 5; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm17(boolean input) {
    if((a510889416==0) && (cf==false)) {
    	calculateOutputm96(input);
    } 
    if((a510889416==0) || (cf==false)) {
    	calculateOutputm97(input);
    } 
}
private  void calculateOutputm113(boolean input) {
    if((a43901077==0) || (a1551570219==0) || (input==false) && (a1944816302==0) && (cf==false)){
    	cf = false;
    	 
    	System.out.println("W");
    } 
    if((a1551570219==0) || (cf==false) && (a43901077==0) || (input==false) || (a1944816302==0)){
    	cf = false;
    	a1649592707 = 0;
    	a1551570219 = 0;
    	a1933271548 = 5; 
    	System.out.println("V");
    } 
    if((a1551570219==0) || (input==false) || (cf==false) && (a1944816302==0) && (a43901077==0)){
    	cf = false;
    	a1669722568 = 0;
    	a1551570219 = 0;
    	a1933271548 = 5; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm22(boolean input) {
    if((cf==false) || (a1944816302==0)){
    	calculateOutputm113(input);
    } 
}
private  void calculateOutputm119(boolean input) {
    if((a1294378386 ==0) || (cf==false) && (a1551570219==0) || (input==false) && (a43901077==0)){
    	cf = false;
    	a1041640432 = 6;
    	a1551570219 = 0;
    	a1379546326 = 12; 
    	System.out.println("T");
    } 
    if((a1294378386 ==0) && (a43901077==0) || (cf==false) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1669722568 = 0;
    	a1384943560 = 0; 
    	System.out.println("X");
    } 
    if((cf==false) && (a43901077==0) || (a1294378386 ==0) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1431178715 = 0;
    	a1041640432 = 9; 
    	System.out.println("X");
    } 
}
private  void calculateOutputm120(boolean input) {
    if((a1294378386 ==0) || (cf==false) || (a43901077==0) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a1868984816 = 10;
    	a1551570219 = 0;
    	a2077863541 = 11; 
    	System.out.println("X");
    } 
    if((a1551570219==0) && (a1294378386 ==0) || (a43901077==0) || (cf==false) && (input==false)){
    	cf = false;
    	a1669722568 = 0;
    	a1551570219 = 0;
    	a1583922005 = 10; 
    	System.out.println("U");
    } 
    if((a1294378386 ==0) || (a1551570219==0) || (a43901077==0) && (cf==false) || (input==false)){
    	cf = false;
    	a1796618233 = 0;
    	a1551570219 = 0;
    	a1868984816 = 13; 
    	System.out.println("V");
    } 
}
private  void calculateOutputm23(boolean input) {
    if((cf==false) || (a1294378386 ==0)){
    	calculateOutputm119(input);
    } 
    if((cf==false) && (a1294378386 ==0)){
    	calculateOutputm120(input);
    } 
}
private  void calculateOutputm129(boolean input) {
    if((a1868984816 ==0) && (input==false) || (a1551570219==0) || (cf==false) && (a469914660 ==0)){
    	cf = false;
    	a1551570219 = 0;
    	a43901077 = 0;
    	a1944816302 = 0; 
    	System.out.println("T");
    } 
    if((a1868984816 ==0) || (cf==false) && (a469914660 ==0) || (a1551570219==0) && (input==false)){
    	cf = false;
    	a1868984816 = 9;
    	a1591641889 = 4; 
    	System.out.println("S");
    } 
    if((cf==false) || (input==false) && (a469914660 ==0) || (a1868984816 ==0) && (a1551570219==0)){
    	cf = false;
    	a469914660 = 14; 
    	System.out.println("U");
    } 
    if((a1868984816 ==0) && (a469914660 ==0) || (cf==false) || (input==false) && (a1551570219==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1669722568 = 0;
    	a1450658394 = 12; 
    	System.out.println("Y");
    } 
}
private  void calculateOutputm27(boolean input) {
    if((a469914660 ==0) && (cf==false)) {
    	calculateOutputm129(input);
    } 
}
private  void calculateOutputm131(boolean input) {
    if((a1551570219==0) || (cf==false) && (a1868984816 ==0) || (a1591641889 ==0) && (input==false)){
    	cf = false;
    	a1868984816 = 11;
    	a927814483 = 14; 
    	System.out.println("U");
    } 
    if((cf==false) || (input==false) && (a1551570219==0) || (a1868984816 ==0) && (a1591641889 ==0)){
    	cf = false;
    	a510889416 = 0;
    	a1551570219 = 0;
    	a1933271548 = 6; 
    	System.out.println("S");
    } 
    if((input==false) && (a1868984816 ==0) || (cf==false) || (a1551570219==0) && (a1591641889 ==0)){
    	cf = false;
    	a1669722568 = 0;
    	a1551570219 = 0;
    	a1450658394 = 9; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm137(boolean input) {
    if((a1868984816 ==0) || (a1591641889 ==0) && (cf==false) || (input==false) && (a1551570219==0)){
    	cf = false;
    	 
    	System.out.println("X");
    } 
    if((a1868984816 ==0) && (a1591641889 ==0) || (a1551570219==0) || (cf==false) || (input==false)){
    	cf = false;
    	a1796618233 = 0;
    	a1868984816 = 13; 
    	System.out.println("V");
    } 
    if((input==false) || (cf==false) && (a1868984816 ==0) || (a1591641889 ==0) && (a1551570219==0)){
    	cf = false;
    	a1551570219 = 0;
    	a43901077 = 0;
    	a1944816302 = 0; 
    	System.out.println("W");
    } 
}
private  void calculateOutputm28(boolean input) {
    if((a1591641889 ==0) && (cf==false)) {
    	calculateOutputm131(input);
    } 
    if((cf==false) || (a1591641889 ==0)){
    	calculateOutputm137(input);
    } 
}
private  void calculateOutputm139(boolean input) {
    if((input==false) && (a2077863541 ==0) || (cf==false) || (a1551570219==0) && (a1868984816 ==0)){
    	cf = false;
    	a1551570219 = 0;
    	a43901077 = 0;
    	a1294378386 = 11; 
    	System.out.println("T");
    } 
    if((cf==false) || (input==false) || (a1868984816 ==0) && (a2077863541 ==0) && (a1551570219==0)){
    	cf = false;
    	a1669722568 = 0;
    	a1551570219 = 0;
    	a1583922005 = 10; 
    	System.out.println("U");
    } 
}
private  void calculateOutputm29(boolean input) {
    if((a2077863541 ==0) && (cf==false)) {
    	calculateOutputm139(input);
    } 
}
private  void calculateOutputm145(boolean input) {
    if((a1868984816 ==0) || (a1551570219==0) || (input==false) && (cf==false) && (a927814483 ==0)){
    	cf = false;
    	a1868984816 = 9;
    	a1591641889 = 4; 
    	System.out.println("S");
    } 
}
private  void calculateOutputm30(boolean input) {
    if((a927814483 ==0) && (cf==false)) {
    	calculateOutputm145(input);
    } 
}
private  void calculateOutputm152(boolean input) {
    if((a1868984816 ==0) && (input==false) || (a1796618233==0) || (cf==false) || (a1551570219==0)){
    	cf = false;
    	a43901077 = 0;
    	a1551570219 = 0;
    	a1944816302 = 0; 
    	System.out.println("W");
    } 
    if((input==false) || (a1551570219==0) && (cf==false) || (a1796618233==0) && (a1868984816 ==0)){
    	cf = false;
    	a1868984816 = 9;
    	a1591641889 = 11; 
    	System.out.println("X");
    } 
    if((a1551570219==0) && (input==false) || (a1796618233==0) && (cf==false) || (a1868984816 ==0)){
    	cf = false;
    	a1551570219 = 0;
    	a1933271548 = 9;
    	a927814483 = 9; 
    	System.out.println("T");
    } 
}
private  void calculateOutputm32(boolean input) {
    if((cf==false) || (a1796618233==0)){
    	calculateOutputm152(input);
    } 
}



public  void calculateOutput(boolean input) {
 	cf = true;
    if((cf==false) || (a1551570219==0)){
    	if((a1669722568==0) && (cf==false)) {
    		calculateOutputm1(input);
    	} 
    	if((a1669722568==0) && (cf==false)) {
    		calculateOutputm2(input);
    	} 
    	if((a1669722568==0) || (cf==false)) {
    		calculateOutputm5(input);
    	} 
    } 
    if((cf==false) && (a1551570219==0)){
    	if((a1041640432 ==0) && (cf==false)) {
    		calculateOutputm7(input);
    	} 
    	if((a1041640432 ==0) || (cf==false)) {
    		calculateOutputm8(input);
    	} 
    	if((cf==false) && (a1041640432 ==0)){
    		calculateOutputm11(input);
    	} 
    	if((a1041640432 ==0) || (cf==false)) {
    		calculateOutputm12(input);
    	} 
    	if((a1041640432 ==0) && (cf==false)) {
    		calculateOutputm13(input);
    	} 
    } 
    if((cf==false) && (a1551570219==0)){
    	if((cf==false) || (a1933271548 ==0)){
    		calculateOutputm16(input);
    	} 
    	if((a1933271548 ==0) && (cf==false)) {
    		calculateOutputm17(input);
    	} 
    } 
    if((cf==false) && (a1551570219==0)){
    	if((cf==false) || (a43901077==0)){
    		calculateOutputm22(input);
    	} 
    	if((a43901077==0) && (cf==false)) {
    		calculateOutputm23(input);
    	} 
    } 
    if((cf==false) || (a1551570219==0)){
    	if((a1868984816 ==0) && (cf==false)) {
    		calculateOutputm27(input);
    	} 
    	if((cf==false) && (a1868984816 ==0)){
    		calculateOutputm28(input);
    	} 
    	if((cf==false) || (a1868984816 ==0)){
    		calculateOutputm29(input);
    	} 
    	if((cf==false) && (a1868984816 ==0)){
    		calculateOutputm30(input);
    	} 
    	if((a1868984816 ==0) || (cf==false)) {
    		calculateOutputm32(input);
    	} 
    } 

    errorCheck();
    if(cf==false)
    	throw new IllegalArgumentException("Current state has no transition for this input!");
}


public static void main() throws Exception 
	{
	     // init system and input reader
            Problem10_RERS2018 eca = new Problem10_RERS2018();
        int a=0;
	int x;
        int y;
         
        x = Cute.input.Integer();
        y = Cute.input.Integer();
		boolean input = Cute.input.Boolean();
			// main i/o-loop
            while(a<10) //Sanghu changed the bound from 10 to 1.
            {
            	
                try{
                	 if (x>199 && x>y){
           System.out.println("X is greater than 199 and also greater than y");
                	 eca.calculateOutput(input);
					 
				}
				
				if (x>299 && x<y){
            System.out.println("X is greater than 299 but  lesser than y");
		
			eca.calculateOutput(input);
        }
                } catch(IllegalArgumentException e){
    	    		System.err.println("Invalid input: " + e.getMessage());
                }
				
				a++;
	    	}
	}
}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=0
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
