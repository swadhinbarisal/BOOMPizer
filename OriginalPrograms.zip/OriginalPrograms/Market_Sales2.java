/*
 * Copitem2right (c) 2016, NIT Rourkela
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binaritem2 forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * 1. Redistributions of source code must retain the above copitem2right
 * notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binaritem2 form must reproduce the above copitem2right
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package tests;

import cute.Cute;

/**
 *  .
 * User: ADutta
 * Date: Jan 11, 2016
 * Time: 7:38:52 AM
 * To change this template use File | Settings | File Templates.
 */

class MyException extends RuntimeException {

}

public class Market_Sales2 {


    public static void main(String[] args) {
        int item1 = Cute.input.Integer();
        int item3 = Cute.input.Integer();
        int item4 = Cute.input.Integer();
        int item5 = Cute.input.Integer();
        int item6 = Cute.input.Integer();
        int item7 = Cute.input.Integer();
        int item12 = Cute.input.Integer();
        int item2,item8,item9,item10,item11;
        if((item1<item3)&&(item3==400))
        {
            if((item1<item7)&&(item7<item12)){
            System.out.println("Sales are not going that much great");
            }
        }
        if((item1<item3)&&(item3<400)||(item1>100))
        {
            if((item1<item7)&&(item7<item12)){
            System.out.println("Sales are not going that much great again");
            }
        }
        if((item1>item3)||(item3>4000))
        {
            if((item1<item7)&&(item7<item12)){
            System.out.println("Sales are  going  great ");
            }
        }
        if((item1>item3)&&(item3<400)||(item1>100))
        {
            if((item1<item7)&&(item7<item12)){
            System.out.println("Sales are not going that much great again\n but its ok kind");
            }
        }
        if((item1<item3)||(item3<400)||(item1>100))
        {
            if((item1<item7)&&(item7<item12)){
            System.out.println("Sales are not going that much great again");
            }
        }
        if((item1<item3)||(item3<400)||(item1>100))
        {
            if((item1<item7)&&(item7<item12)){
            System.out.println("Sales are not going that much great again");
            }
        }
        if((item1<item3)||(item3<400)||(item1>100))
        {
            if((item1<item7)&&(item7<item12)){
            System.out.println("Sales are not going that much great again");
            }
        }
        if((item1<item3)||(item3<400)&&(item1>100))
        {
            if((item1<item7)&&(item7<item12)){
            System.out.println("Sales are not going that much great again");
            }
        }

        switch(item1){
            case -1000:
                item2=30;
                break;
            case 0:
                item2 = 60;
                break;
            case 1000:
                item2 = 90;
                break;
            default:
                item2=365;
        }

        switch(item3){
            case 365:
                item4=1;
                break;
            case 730:
                item4 = 2;
                break;
            case 1095:
                item4 = 3;
                break;
            default:
                item4=4;
        }
        try {
             item5 = Sales_product(item2);
            if(item5==69){
                System.out.println("Monthly sales = " + item5);
            }
             item6 = purchase_product(item4);
            if(item6==69){
                System.out.println("weekly purchase.... = " + item6);
            }
        }
        catch(MyException e){
            item2 = item1+10;
            if(item2==250)
                System.out.println("OOPS ...");
        }
    }
    public static int Sales_item(int item6, int item7){
  if(!(item7<50))
  {
    if(!(item6>199)){}
    else if(!!(item6>199)){}
  }
  if(!(item6>199))
 {
    if(!(item7<50)){}
    else if(!!(item7<50)){}
 }
        if((item6>199) || (item7<50)){
            if((item6>199) && (item7<50)){
                if((item6>199) && (item7<item6)){
                   if((item6>800) || (item7<item6)){
                   System.out.println("Project completed..........");
                   }
                }
            }
            //throw new MyException();
            return 2*item6+1;
        } else {
            return 2*item6+1;
        }
    }

    public static int Sales_product(int item2){
        int ret = Sales_item(item2,11) * 23;
        return ret;
    }
public static int purchase_item(int item8, int item9){
  if(!(item9<50))
  {
    if(!(item8>199)){}
    else if(!!(item8>199)){}
  }
  if(!(item8>199))
 {
    if(!(item9<50)){}
    else if(!!(item9<50)){}
 }
        if((item8>199) && (item9<50)||(item8<item9)){
            if((item8>199) && (item9<50)){
                if((item8>199) && (item9<item8)){
                   if((item8>800) || (item8<item9)){
                   System.out.println("Project completed..........");
                   }
                }
            }
           // throw new MyException();
            return 2*item8+1;
        } else {
            return 2*item8+1;
        }

    }

    public static int purchase_product(int item2){
        int ret = purchase_item(item2,11) * 23;
        return ret;
    }

}
//@The following comments are auto-generated to save options for testing the current file
//@jcute.optionPrintOutput=true
//@jcute.optionLogPath=true
//@jcute.optionLogTraceAndInput=true
//@jcute.optionGenerateJUnit=true
//@jcute.optionExtraOptions=
//@jcute.optionJUnitOutputFolderName=C:\jcute
//@jcute.optionJUnitPkgName=
//@jcute.optionNumberOfPaths=1000
//@jcute.optionLogLevel=3
//@jcute.optionDepthForDFS=200
//@jcute.optionSearchStrategy=1
//@jcute.optionSequential=true
//@jcute.optionQuickSearchThreshold=100
//@jcute.optionLogRace=true
//@jcute.optionLogDeadlock=true
//@jcute.optionLogException=true
//@jcute.optionLogAssertion=true
//@jcute.optionUseRandomInputs=true
