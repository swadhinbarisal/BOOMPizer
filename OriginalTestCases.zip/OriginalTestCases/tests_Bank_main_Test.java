
/* JUnit test case generated automatically by CUTE */
import junit.framework.*;

public class tests_Bank_main_Test extends TestCase implements cute.Input {
    private Object[] input;
    private int i;

    public tests_Bank_main_Test(String name){
        super(name);
    }

    public boolean Boolean() {
        return ((Boolean)input[i++]).booleanValue();
    }

    public short Short() {
        return ((Short)input[i++]).shortValue();
    }

    public int Integer() {
        return ((Integer)input[i++]).intValue();
    }

    public long Long() {
        return ((Long)input[i++]).longValue();
    }

    public float Float() {
        return ((Float)input[i++]).floatValue();
    }

    public double Double() {
        return ((Double)input[i++]).doubleValue();
    }

    public char Character() {
        return ((Character)input[i++]).charValue();
    }

    public byte Byte() {
        return ((Byte)input[i++]).byteValue();
    }

    public Object Object(String type) {
        return input[i++];
    }

    public void test1(){
        i=0;
        input = new Object[12];
        input[i++] = new Integer(-2082303562);
        input[i++] = new Integer(766561323);
        input[i++] = new Integer(-294190958);
        input[i++] = new Integer(-162042485);
        input[i++] = new Integer(-1691227278);
        input[i++] = new Integer(508177896);
        input[i++] = new Integer(1090349484);
        input[i++] = new Integer(1153363890);
        input[i++] = new Integer(-1012657858);
        input[i++] = new Integer(-198444197);
        input[i++] = new Integer(-152661171);
        input[i++] = new Integer(-446244848);
        i=0;
        cute.Cute.input = this;
        tests.Bank.main(null);
    }

    public void test2(){
        i=0;
        input = new Object[12];
        input[i++] = new Integer(80);
        input[i++] = new Integer(766561323);
        input[i++] = new Integer(-294190958);
        input[i++] = new Integer(-162042485);
        input[i++] = new Integer(-1691227278);
        input[i++] = new Integer(508177896);
        input[i++] = new Integer(1090349484);
        input[i++] = new Integer(1153363890);
        input[i++] = new Integer(-1012657858);
        input[i++] = new Integer(-198444197);
        input[i++] = new Integer(-152661171);
        input[i++] = new Integer(-446244848);
        i=0;
        cute.Cute.input = this;
        tests.Bank.main(null);
    }

    public void test3(){
        i=0;
        input = new Object[16];
        input[i++] = new Integer(80);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-294190958);
        input[i++] = new Integer(-162042485);
        input[i++] = new Integer(-1691227278);
        input[i++] = new Integer(508177896);
        input[i++] = new Integer(1090349484);
        input[i++] = new Integer(1153363890);
        input[i++] = new Integer(-1012657858);
        input[i++] = new Integer(-198444197);
        input[i++] = new Integer(-152661171);
        input[i++] = new Integer(-446244848);
        input[i++] = new Integer(1794826429);
        input[i++] = new Integer(1492360382);
        input[i++] = new Integer(243600612);
        input[i++] = new Integer(-210510000);
        i=0;
        cute.Cute.input = this;
        tests.Bank.main(null);
    }

    public void test5(){
        i=0;
        input = new Object[20];
        input[i++] = new Integer(80);
        input[i++] = new Integer(0);
        input[i++] = new Integer(441);
        input[i++] = new Integer(-162042485);
        input[i++] = new Integer(-1691227278);
        input[i++] = new Integer(508177896);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1012657858);
        input[i++] = new Integer(-198444197);
        input[i++] = new Integer(-152661171);
        input[i++] = new Integer(-446244848);
        input[i++] = new Integer(1794826429);
        input[i++] = new Integer(1492360382);
        input[i++] = new Integer(243600612);
        input[i++] = new Integer(-210510000);
        input[i++] = new Integer(1694022217);
        input[i++] = new Integer(-713358732);
        input[i++] = new Integer(2050200542);
        input[i++] = new Integer(-696784921);
        i=0;
        cute.Cute.input = this;
        tests.Bank.main(null);
    }

    public void test6(){
        i=0;
        input = new Object[20];
        input[i++] = new Integer(80);
        input[i++] = new Integer(0);
        input[i++] = new Integer(441);
        input[i++] = new Integer(701);
        input[i++] = new Integer(-1691227278);
        input[i++] = new Integer(508177896);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1012657858);
        input[i++] = new Integer(-198444197);
        input[i++] = new Integer(-152661171);
        input[i++] = new Integer(-446244848);
        input[i++] = new Integer(1794826429);
        input[i++] = new Integer(1492360382);
        input[i++] = new Integer(243600612);
        input[i++] = new Integer(-210510000);
        input[i++] = new Integer(1694022217);
        input[i++] = new Integer(-713358732);
        input[i++] = new Integer(2050200542);
        input[i++] = new Integer(-696784921);
        i=0;
        cute.Cute.input = this;
        tests.Bank.main(null);
    }

    public void test7(){
        i=0;
        input = new Object[16];
        input[i++] = new Integer(80);
        input[i++] = new Integer(46);
        input[i++] = new Integer(441);
        input[i++] = new Integer(701);
        input[i++] = new Integer(-1691227278);
        input[i++] = new Integer(508177896);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1012657858);
        input[i++] = new Integer(-198444197);
        input[i++] = new Integer(-152661171);
        input[i++] = new Integer(-446244848);
        input[i++] = new Integer(1794826429);
        input[i++] = new Integer(1492360382);
        input[i++] = new Integer(243600612);
        input[i++] = new Integer(-210510000);
        i=0;
        cute.Cute.input = this;
        tests.Bank.main(null);
    }

    public void test9(){
        i=0;
        input = new Object[12];
        input[i++] = new Integer(80);
        input[i++] = new Integer(46);
        input[i++] = new Integer(0);
        input[i++] = new Integer(701);
        input[i++] = new Integer(-1691227278);
        input[i++] = new Integer(508177896);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1012657858);
        input[i++] = new Integer(-198444197);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        tests.Bank.main(null);
    }

    public void test11(){
        i=0;
        input = new Object[12];
        input[i++] = new Integer(0);
        input[i++] = new Integer(46);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        input[i++] = new Integer(-1691227278);
        input[i++] = new Integer(508177896);
        input[i++] = new Integer(0);
        input[i++] = new Integer(1);
        input[i++] = new Integer(-1012657858);
        input[i++] = new Integer(-198444197);
        input[i++] = new Integer(0);
        input[i++] = new Integer(0);
        i=0;
        cute.Cute.input = this;
        tests.Bank.main(null);
    }

}
